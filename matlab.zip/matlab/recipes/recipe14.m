%% A constrained experiment manifest
clear; close all; clc;
here=fileparts(mfilename('fullpath')); addpath(fullfile(here,'..','core'));
Ts=0.01; manifest=struct();
manifest.model=struct('a',exp(-Ts),'b',1-exp(-Ts));
manifest.reference=0.6; manifest.initial=0; manifest.sampleTime=Ts;
manifest.requirements=struct('settlingSeconds',8,'minCommand',0,'maxCommand',1);
manifest.environment=version;
p=struct('Kp',2,'Ki',1,'Kd',0,'Tf',0.05,'Ts',Ts, ...
    'beta',1,'lo',0,'hi',1,'Kaw',3);
y=0; s=pidInit(0,0,0,p); t=0:Ts:12; Y=zeros(size(t)); U=Y;
for k=1:numel(t)
    Y(k)=y; [U(k),s]=pidStep(manifest.reference,y,s,p);
    y=manifest.model.a*y+manifest.model.b*U(k);
end
manifest.metrics=stepMetrics(t,Y,manifest.reference,manifest.initial);
manifest.accepted.command=all(U>=0 & U<=1);
manifest.accepted.finite=all(isfinite(Y));
manifest.accepted.settling=isfinite(manifest.metrics.settling) && ...
    manifest.metrics.settling<=manifest.requirements.settlingSeconds;
manifest.data=struct('time',t,'output',Y,'command',U);
disp(manifest.accepted);
% save('manifest.mat','manifest'); % Optional explicit local write.
