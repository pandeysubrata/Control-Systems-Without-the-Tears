%% Move-rate constraints need coupled inequalities
clear; close all; clc;
here=fileparts(mfilename('fullpath')); addpath(fullfile(here,'..','core'));
assert(exist('quadprog','file')==2,'Optimization Toolbox is required.');
N=15; [F,G]=predictionMatrices(0.95,0.1,1,N);
x=0; r=ones(N,1); previous=0.2; rate=0.08;
D=eye(N)-diag(ones(N-1,1),-1); offset=[previous;zeros(N-1,1)];
Q=eye(N); moveWeight=0.2; H=2*(G'*Q*G+moveWeight*(D'*D));
f=2*(G'*Q*(F*x-r)-moveWeight*D'*offset);
Aineq=[D;-D]; bineq=[rate*ones(N,1)+offset;rate*ones(N,1)-offset];
options=optimoptions('quadprog','Display','off');
[U,~,flag]=quadprog(H,f,Aineq,bineq,[],[],zeros(N,1),ones(N,1),[],options);
assert(flag>0 && all(isfinite(U)),'QP did not provide an accepted solution.');
increments=D*U-offset;
assert(max(abs(increments))<=rate+1e-7);
stairs(0:N,[previous;U]); xlabel('Future move'); ylabel('Command');
