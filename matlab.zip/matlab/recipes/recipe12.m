%% A finite-difference audit of the nonlinear cart
clear; close all; clc;
here=fileparts(mfilename('fullpath')); addpath(fullfile(here,'..','core'));
m=bookModels(); x0=zeros(4,1); h=1e-6; An=zeros(4);
for j=1:4
    delta=zeros(4,1); delta(j)=h;
    plus=cartDynamics(0,x0+delta,0,m.cart);
    minus=cartDynamics(0,x0-delta,0,m.cart);
    An(:,j)=(plus-minus)/(2*h);
end
Bn=(cartDynamics(0,x0,h,m.cart)-cartDynamics(0,x0,-h,m.cart))/(2*h);
fprintf('A discrepancy: %g\n',norm(An-m.cart.A,Inf));
fprintf('B discrepancy: %g\n',norm(Bn-m.cart.B,Inf));
assert(norm(An-m.cart.A,Inf)<1e-6);
assert(norm(Bn-m.cart.B,Inf)<1e-8);
