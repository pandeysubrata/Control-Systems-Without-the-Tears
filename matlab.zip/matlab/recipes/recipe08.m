%% A soft predicted-temperature bound
clear; close all; clc;
here=fileparts(mfilename('fullpath')); addpath(fullfile(here,'..','core'));
assert(exist('quadprog','file')==2,'Optimization Toolbox is required.');
N=20; a=exp(-2/80); [A,B,C]=delayPlant(a,2*(1-a),3);
[F,G]=predictionMatrices(A,B,C,N); x=[1.2;1;1;1];
r=ones(N,1); R=0.03*eye(N); rho=1e4; ymax=1.1;
H=blkdiag(2*(G'*G+R),2*rho);
f=[2*(G'*(F*x-r)-R*(0.5*ones(N,1)));0];
Aineq=[G -ones(N,1)]; bineq=ymax*ones(N,1)-F*x;
lo=[zeros(N,1);0]; hi=[ones(N,1);Inf];
options=optimoptions('quadprog','Display','off');
[z,~,flag]=quadprog(H,f,Aineq,bineq,[],[],lo,hi,[],options);
assert(flag>0,'Soft-constrained QP did not solve.');
U=z(1:N); slack=z(end); Y=F*x+G*U;
fprintf('Shared slack: %.5g normalized, %.5g deg C\n',slack,40*slack);
assert(max(Y-ymax-slack)<1e-6);
plot(1:N,Y,1:N,ymax+0*Y,'--'); xlabel('Prediction step'); ylabel('Normalized temperature');
