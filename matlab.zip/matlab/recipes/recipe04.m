%% Discrete process covariance from a continuous model
clear; close all; clc;
here=fileparts(mfilename('fullpath')); addpath(fullfile(here,'..','core'));
Ts=0.1; A=[0 1;0 0]; G=[0;1]; qc=0.4;
W=G*qc*G'; n=size(A,1);
E=expm([A W;zeros(n) -A']*Ts);
Ad=E(1:n,1:n); V=E(1:n,n+1:2*n);
Qd=V*Ad'; Qd=(Qd+Qd')/2;
expected=qc*[Ts^3/3 Ts^2/2;Ts^2/2 Ts];
disp(Qd);
assert(norm(Qd-expected,Inf)<1e-12);
assert(min(eig(Qd))>=-1e-12);
% Repeat at a different Ts; do not retain the old Qd unchanged.
