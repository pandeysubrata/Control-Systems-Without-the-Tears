%% Separate reference, disturbance and noise paths
clear; close all; clc;
here=fileparts(mfilename('fullpath')); addpath(fullfile(here,'..','core'));
assert(exist('tf','file')==2,'Control System Toolbox is required.');
s=tf('s'); P=1/(s+1); C=2+1/s;
S=feedback(1,P*C); T=feedback(P*C,1);
t=(0:0.002:10)'; r=ones(size(t)); d=0.2*(t>=5);
noise=0.02*sin(80*t);
yReference=lsim(T,r,t); yDisturbance=lsim(S,d,t);
yNoise=lsim(-T,noise,t);
uNoise=lsim(-C*S,noise,t);
subplot(2,1,1); plot(t,yReference+yDisturbance+yNoise);
ylabel('Physical output');
subplot(2,1,2); plot(t,uNoise); ylabel('Noise-induced command');
xlabel('Time (s)');
% The ideal PI controller is proper here; derivative needs filtering.
