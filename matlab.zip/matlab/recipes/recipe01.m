%% Transfer-function and state-space agreement
clear; close all; clc;
here=fileparts(mfilename('fullpath')); addpath(fullfile(here,'..','core'));
assert(exist('ss','file')==2,'Control System Toolbox is required.');
m=bookModels(); s=tf('s');
Ptf=m.motor.K/((m.motor.L*s+m.motor.R)* ...
    (m.motor.J*s+m.motor.b)+m.motor.K^2);
Pss=ss(m.motor.A,m.motor.B,m.motor.C,0);
t=(0:0.001:3)'; u=3*(t>=0.1 & t<1.5);
y1=lsim(Ptf,u,t); y2=lsim(Pss,u,t);
fprintf('Largest representation discrepancy: %g\n',max(abs(y1-y2)));
assert(max(abs(y1-y2))<1e-7);
fprintf('Transfer DC gain: %g\n',dcgain(Ptf));
plot(t,y1,t,y2,'--'); xlabel('Time (s)'); ylabel('Speed (rad/s)');
legend('Physical transfer function','State-space realization');
