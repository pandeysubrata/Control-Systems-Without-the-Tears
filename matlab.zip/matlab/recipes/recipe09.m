%% The MPC Toolbox route
clear; close all; clc;
here=fileparts(mfilename('fullpath')); addpath(fullfile(here,'..','core'));
assert(exist('mpc','file')==2,'Model Predictive Control Toolbox is required.');
Ts=2; a=exp(-Ts/80); b=2*(1-a);
plant=ss(a,b,1,0,Ts);
controller=mpc(plant,Ts,20,5);
controller.MV.Min=0; controller.MV.Max=1;
controller.Weights.OutputVariables=1;
controller.Weights.ManipulatedVariablesRate=0.1;
state=mpcstate(controller); x=0; N=100; Y=zeros(1,N); U=Y;
for k=1:N
    Y(k)=x;
    U(k)=mpcmove(controller,state,Y(k),1);
    x=a*x+b*U(k);
end
plotPair((0:N-1)*Ts,40*Y,100*U,40,'Toolbox scalar thermal example');
% This particular recipe omits the input delay; add it deliberately.
% Inspect estimator and disturbance-model defaults before comparison.
