%% Convergence of an estimator covariance
clear; close all; clc;
here=fileparts(mfilename('fullpath')); addpath(fullfile(here,'..','core'));
Ts=0.05; A=[1 Ts;0 1]; C=[1 0];
Q=diag([1e-5 1e-4]); R=0.04; P=100*eye(2);
N=500; gains=zeros(2,N); traceP=zeros(1,N);
for k=1:N
    Pp=A*P*A'+Q; S=C*Pp*C'+R; L=(Pp*C')/S;
    E=eye(2)-L*C; P=E*Pp*E'+L*R*L';
    P=(P+P')/2; gains(:,k)=L; traceP(k)=trace(P);
end
subplot(2,1,1); plot(gains'); ylabel('Gain entries');
legend('Position correction','Velocity correction');
subplot(2,1,2); semilogy(traceP); ylabel('Covariance trace'); xlabel('Sample');
fprintf('Last gain change: %g\n',norm(gains(:,end)-gains(:,end-1)));
