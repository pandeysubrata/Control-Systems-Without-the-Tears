%% Check a prediction solver against an independent objective
clear; close all; clc;
here=fileparts(mfilename('fullpath')); addpath(fullfile(here,'..','core'));
A=0.9; B=0.2; C=1; N=8; x0=0.3;
[F,G]=predictionMatrices(A,B,C,N);
U=linspace(0.1,0.8,N)'; target=ones(N,1); us=0.5*ones(N,1);
Q=eye(N); R=0.2*eye(N); Y=F*x0+G*U;
condensed=(Y-target)'*Q*(Y-target)+(U-us)'*R*(U-us);
x=x0; direct=0;
for j=1:N
    x=A*x+B*U(j); direct=direct+(C*x-target(j))^2+0.2*(U(j)-us(j))^2;
end
H=2*(G'*Q*G+R); f=2*(G'*Q*(F*x0-target)-R*us);
objective=@(z) 0.5*z'*H*z+f'*z;
gradient=zeros(N,1); h=1e-6;
for j=1:N
    d=zeros(N,1); d(j)=h;
    gradient(j)=(objective(U+d)-objective(U-d))/(2*h);
end
assert(abs(condensed-direct)<1e-12);
assert(norm(gradient-(H*U+f),Inf)<1e-7);
disp('Prediction cost and gradient checks passed.');
