%% Estimate a constant input disturbance explicitly
clear; close all; clc;
here=fileparts(mfilename('fullpath')); addpath(fullfile(here,'..','core'));
rng(6); a=0.95; b=0.1; A=[a 1;0 1]; B=[b;0]; C=[1 0];
Q=diag([1e-5 1e-6]); R=1e-3; x=0; xh=zeros(2,1); P=eye(2);
N=300; estimate=zeros(1,N); truth=estimate; output=estimate; u=0.5;
for k=1:N
    d=-0.02*(k>100); x=a*x+b*u+d;
    y=x+sqrt(R)*randn;
    [xh,P]=kalmanStep(xh,P,u,y,A,B,C,Q,R);
    estimate(k)=xh(2); truth(k)=d; output(k)=y;
end
plot(truth,'--'); hold on; plot(estimate);
xlabel('Sample'); ylabel('State-update disturbance'); legend('True','Estimated');
r=1; us=((1-a)*r-xh(2))/b;
fprintf('Estimated target input: %g\n',us);
