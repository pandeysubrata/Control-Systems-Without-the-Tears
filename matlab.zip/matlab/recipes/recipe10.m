%% A transparent model-validation split
clear; close all; clc;
here=fileparts(mfilename('fullpath')); addpath(fullfile(here,'..','core'));
rng(10); N=1000; u=repelem(2*(rand(1,100)>0.5)-1,10);
y=zeros(1,N); a=0.94; b=0.08;
for k=1:N-1, y(k+1)=a*y(k)+b*u(k)+0.01*randn; end
[ahat,bhat]=fitARX1(u(1:500),y(1:500));
prediction=zeros(1,500); prediction(1)=y(501);
for j=1:499
    prediction(j+1)=ahat*prediction(j)+bhat*u(500+j);
end
residual=y(501:end)-prediction;
fprintf('Validation RMSE: %g\n',sqrt(mean(residual.^2)));
subplot(2,1,1); plot(501:N,y(501:end),501:N,prediction);
ylabel('Output'); legend('Held-out data','Free simulation');
subplot(2,1,2); plot(501:N,residual); ylabel('Residual'); xlabel('Sample');
