%% A lead compensator as a difference equation
clear; close all; clc;
here=fileparts(mfilename('fullpath')); addpath(fullfile(here,'..','core'));
Ts=0.01; K=1; z0=2; p0=10; q=2/Ts;
b0=K*(q+z0)/(q+p0); b1=K*(z0-q)/(q+p0);
a1=(p0-q)/(q+p0);
t=0:Ts:5; e=double(t>=0.2); u=zeros(size(t));
previousError=0; previousOutput=0;
for k=1:numel(t)
    u(k)=b0*e(k)+b1*previousError-a1*previousOutput;
    previousError=e(k); previousOutput=u(k);
end
w=logspace(-1,2,500); delay=exp(-1i*w*Ts);
Cd=(b0+b1*delay)./(1+a1*delay);
Cc=K*(1i*w+z0)./(1i*w+p0);
subplot(2,1,1); semilogx(w,20*log10(abs(Cc)),w,20*log10(abs(Cd)),'--');
ylabel('Magnitude (dB)'); legend('Continuous','Bilinear');
subplot(2,1,2); plot(t,u); xlabel('Time (s)'); ylabel('Step output');
