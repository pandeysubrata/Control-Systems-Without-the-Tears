%% Chapter 20: short experiment
% Intended as a short run; actual timing depends on MATLAB and hardware.
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
% Outer position loop requests speed; inner PI supplies voltage.
m=bookModels(); Ts=0.002; [A,B]=zohExact(m.motor.A,m.motor.B,Ts);
p=struct('Kp',0.8,'Ki',2,'Kd',0,'Tf',0.02,'Ts',Ts, ...
         'beta',1,'lo',-12,'hi',12,'Kaw',4);
x=[0;0]; pos=0; s=pidInit(0,0,0,p); t=0:Ts:8;
y=zeros(size(t)); u=y; speed=y; target=4;
for k=1:numel(t)
    y(k)=pos; speed(k)=x(2);
    speedRef=min(8,max(-8,2*(target-pos)));
    [u(k),s]=pidStep(speedRef,x(2),s,p);
    pos=pos+Ts*x(2); x=A*x+B*u(k);
end
plotPair(t,y,u,target,'Cascaded motor position control');
% Position Euler integration is a declared approximation; refine Ts to check it.
