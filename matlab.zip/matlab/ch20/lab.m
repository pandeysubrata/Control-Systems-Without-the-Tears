%% Extended investigation: Encoder resolution creates a velocity trade-off
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
Ts=0.001; t=0:Ts:3; countsPerRev=2048;
position=2*t+0.3*sin(2*pi*t);
trueSpeed=2+0.6*pi*cos(2*pi*t);
counts=round(position*countsPerRev/(2*pi));
quantized=counts*(2*pi/countsPerRev);
figure; plot(t,trueSpeed,'k','LineWidth',1.2); hold on;
for window=[0.005 0.02 0.05]
    n=round(window/Ts); velocity=NaN(size(t));
    velocity(n+1:end)=(quantized(n+1:end)-quantized(1:end-n))/(n*Ts);
    plot(t,velocity,'DisplayName',sprintf('Window %.3g s',n*Ts));
    fprintf('Window %.3g s: one-count speed increment %.4g rad/s\n', ...
        n*Ts,2*pi/(countsPerRev*n*Ts));
end
xlabel('Time (s)'); ylabel('Speed (rad/s)');
legend('Truth','5 ms','20 ms','50 ms');
% The first n estimates are undefined, not zero-speed measurements.
% Try a constant low speed where count transitions are sparse.
