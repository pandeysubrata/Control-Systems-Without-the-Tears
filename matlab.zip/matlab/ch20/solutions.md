# Chapter 20: exercise guidance

The typeset version is in Appendix D of the book. Mathematical notation is retained below.

## Exercise 1

Using $[i,\omega,\theta]^T$, set $A=[-100,-4,0;4,-2,0;0,1,0]$, $B=[50,0,0]^T$. Position output is $C=[0,0,1]$. Exact ZOH of this augmented model accounts for speed variation within each sample when updating position. It avoids the mixed approximation that simply adds $T_s\omega_k$.

## Exercise 2

One decoded count corresponds to $2\pi/2048$ radians. Over 0.02 s the speed increment is $2\pi/(2048\cdot0.02)\approx0.153398$ rad/s. The count definition matters: pulses, edges and decoded quadrature counts can differ by a factor of four. State which convention the encoder interface uses.

## Exercise 3

Discretize the full three-state model with the same held voltage and compare position, speed and current. The mixed method has a position integration approximation even when its two-state motor update is exact. Repeat at half the sample interval to assess convergence. Use identical controller sampling and reference timing in both cases.

## Exercise 4

Increase the outer gain in declared increments while preserving the inner loop and all limits. Record position overshoot, speed-reference clipping, voltage clipping and settling. The first violated requirement depends on the chosen thresholds; report it explicitly. Do not assume the nominal fastest response is the best cascade design.

## Exercise 5

Add a stated dead-zone or friction law with units and a clear zero-speed convention. Compare low-speed tracking, limit cycles and required integral contribution. A discontinuous Coulomb-friction model can be numerically delicate near zero; distinguish numerical chatter from a physical stick-slip claim. A smooth approximation changes the model and should be identified.

## Exercise 6

Verify sensor scale and sign, test bounded open-loop actuation, close the speed loop conservatively, then enable the position loop with limited references. Check current, travel and disable behavior at each stage. The independent disable path must not rely solely on the controller task that is being tested. Actual acceptance limits depend on the hardware and its hazards.