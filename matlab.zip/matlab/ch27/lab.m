%% Extended investigation: Turn a promising experiment into an auditable result
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
report=struct(); report.title='Scalar PI acceptance experiment';
report.matlab=version; report.sampleTime=0.01;
report.model=struct('a',exp(-0.01),'b',1-exp(-0.01));
report.requirements=struct('settlingLimit',8,'commandLimit',1);
p=struct('Kp',2,'Ki',1,'Kd',0,'Tf',0.05,'Ts',0.01, ...
    'beta',1,'lo',0,'hi',1,'Kaw',3);
report.controller=p; t=0:0.01:12; y=0; s=pidInit(0,0,0,p);
Y=zeros(size(t)); U=Y;
for k=1:numel(t)
    Y(k)=y; [U(k),s]=pidStep(0.6,y,s,p);
    y=report.model.a*y+report.model.b*U(k);
end
report.metrics=stepMetrics(t,Y,0.6,0);
report.pass.finite=all(isfinite(Y)) && all(isfinite(U));
report.pass.command=max(abs(U))<=report.requirements.commandLimit+1e-12;
report.pass.settling=isfinite(report.metrics.settling) && ...
    report.metrics.settling<=report.requirements.settlingLimit;
report.time=t; report.output=Y; report.appliedCommand=U;
disp(report.pass);
% Uncomment to save the complete record in the current directory.
% save('acceptance_record.mat','report');
% Add source revision and measured platform timing before deployment claims.
