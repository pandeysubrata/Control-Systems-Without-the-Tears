%% Chapter 27: short experiment
% Intended as a short run; actual timing depends on MATLAB and hardware.
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
% Your next course begins with an experiment you can reproduce.
m=bookModels(); Ts=0.01; [A,B]=zohExact(m.motor.A,m.motor.B,Ts);
assert(max(abs(eig(A)))<1); % open-loop motor model is stable
[Q,R]=deal(diag([0.01 1]),0.2);
[K,~,info]=riccatiDiscrete(A,B,Q,R);
report=struct('date',datestr(now,30),'matlabVersion',version, ...
              'sampleTime',Ts,'gain',K,'radius',info.radius);
disp(report);
% Saving is optional; uncomment to create a provenance record.
% save('my_next_control_experiment.mat','report','A','B','Q','R');
% Questions: What can be measured? What can saturate? What model is uncertain?
