# Chapter 27: exercise guidance

The typeset version is in Appendix D of the book. Mathematical notation is retained below.

## Exercise 1

Replace adjectives with numerical thresholds under declared conditions: a target band and settling deadline, a peak applied voltage, and a maximum error over a stated uncertainty set are examples. Include the reference profile, initial condition and measurement convention. Requirements should be chosen for the actual application, not adjusted afterward to make the preferred controller pass.

## Exercise 2

Include motor constants, state order and units, sample interval, initial state, reference, disturbance path and sequence, actuator limits, PID parameters, initialization rule, solver or discretization method, software version and exact source revision. Save output and command arrays with timestamps. A plot alone does not preserve enough information to reproduce the run.

## Exercise 3

A controller can achieve a small IAE by using excessive force, violating a temperature limit or missing deadlines in rare cases. A single scalar average can also hide a severe short excursion. Treat hard requirements and failures separately, then use tracking and effort scores to compare the acceptable candidates.

## Exercise 4

Choose a scenario in which the claimed advantage should matter, such as a known scheduled reduction with input delay and duty limits. Keep model information and constraints equal. Define a performance threshold and computation budget in advance. If a well-tuned PI baseline meets them as well or better, the claimed advantage is not supported for that scenario.

## Exercise 5

A useful plan alternates theory, implementation and evidence. For example: model a sensor delay, derive its phase effect, implement it, redesign the loop, compare uncertainty cases, then write a reproducible report. Tie each week to an observable deliverable and one unanswered question. Reading an entire advanced text without an experiment is not the only route to progress.

## Exercise 6

The dossier should state requirements, model assumptions, sensor and actuator limits, controller choice, validation scenarios, results and the strongest unresolved limitation. A strong limitation is specific: for example, only nominal simulation was tested, the delay estimate is uncertain, or the target processor timing is unmeasured. Explain which next experiment would most reduce that uncertainty.