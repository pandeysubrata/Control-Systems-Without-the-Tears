%% Extended investigation: The fastest pole may demand impossible voltage
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
Ts=0.002; t=0:Ts:4; gains=[0.2 1 4 12];
a=exp(-2.16*Ts); b=(2/2.16)*(1-a); results=[];
figure;
for kp=gains
    y=0; Y=zeros(size(t)); U=Y; V=Y;
    for k=1:numel(t)
        v=kp*(10-y); u=min(12,max(-12,v));
        Y(k)=y; U(k)=u; V(k)=v;
        y=a*y+b*u;
    end
    results(end+1,:)=[kp 10-Y(end) max(abs(V)) ...
        Ts*sum(abs(V-U)>1e-10)]; %#ok<AGROW>
    subplot(2,1,1); hold on; plot(t,Y,'DisplayName',num2str(kp));
    subplot(2,1,2); hold on; plot(t,U,'DisplayName',num2str(kp));
end
subplot(2,1,1); ylabel('Speed (rad/s)'); legend('show');
subplot(2,1,2); ylabel('Applied voltage (V)'); xlabel('Time (s)');
disp('Kp, final error, peak requested voltage, clipped duration');
disp(results);
% Add a ramp reference and repeat without changing the actuator.
% Keep both voltage signals when comparing the two experiments.
