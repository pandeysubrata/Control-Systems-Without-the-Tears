# Chapter 4

Run `demo.m` for the short experiment and `lab.m` for the extended investigation. Both add the shared core path. Read the chapter for state order, units, assumptions and optional product dependencies. `solutions.md` mirrors Appendix D guidance. MATLAB execution remains to be performed in your intended release.
