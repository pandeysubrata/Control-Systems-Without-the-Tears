%% Chapter 04: short experiment
% Intended as a short run; actual timing depends on MATLAB and hardware.
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
% The reduced motor is useful for understanding P gain, not high-frequency design.
m=bookModels(); K=m.motor.Kdc; tau=m.motor.tau;
Ts=0.005; t=0:Ts:4; a=exp(-Ts/tau); b=K*(1-a);
gains=[0.2 1 4]; r=10;
figure; hold on;
for kp=gains
    x=0; y=zeros(size(t)); u=y;
    for k=1:numel(t)
        y(k)=x; u(k)=kp*(r-x); x=a*x+b*u(k);
    end
    plot(t,y,'LineWidth',1.3);
    fprintf('Kp=%g: predicted final error=%g\n',kp,r/(1+K*kp));
end
plot(t,0*t+r,'k--'); xlabel('Time (s)'); ylabel('Speed (rad/s)');
legend('Kp=0.2','Kp=1','Kp=4','Reference'); grid on;
% Rerun with voltage saturation at +/-12 V to expose the linear-model limit.
