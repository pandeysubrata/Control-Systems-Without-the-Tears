# Chapter 4: exercise guidance

The typeset version is in Appendix D of the book. Mathematical notation is retained below.

## Exercise 1

For $P(s)=K/(\tau s+1)$ and controller $K_p$, unity negative feedback gives $T(s)=KK_p/(\tau s+1+KK_p)$. Its static gain is $KK_p/(1+KK_p)$ and time constant is $\tau/(1+KK_p)$ when the denominator is stable. This derivation assumes an ideal unsaturated actuator and no unmodeled delay.

## Exercise 2

Here $KK_p=6$. The closed-loop time constant is $0.5/7\approx0.0714286$ s and the unit-reference steady error is $1/7\approx0.142857$. The initial requested command is three input units for a unit reference from rest. Before accepting the speed improvement, compare that request with the actual actuator range.

## Exercise 3

The closed-loop pole is $a-bK_p=0.9-0.2K_p$. Require $-1<0.9-0.2K_p<1$. The full interval is $-0.5<K_p<9.5$; restricting to positive gains gives $0<K_p<9.5$. The boundary at 9.5 places the pole at minus one, so it is excluded from asymptotic stability.

## Exercise 4

Clip the requested voltage before the plant update, while storing both values. Report time in clipping, not just peak applied voltage. The initial speed may become insensitive to further gain increases because the actuator already applies its maximum. Compare the response after leaving saturation with the unsaturated pole prediction to identify where the linear model again describes the loop.

## Exercise 5

Nominal feedforward uses the assumed plant equilibrium to supply the required command. An unknown load changes that equilibrium, so the precomputed input is no longer sufficient. Feedback may reduce the resulting error, but P-only feedback usually needs a nonzero error to supply the additional command. Integral action can adapt the steady command when the target remains reachable and the loop remains stable.

## Exercise 6

A ramp or a smooth velocity-limited position profile reduces the abrupt speed request from the outer loop. For a more demanding system, also limit acceleration and possibly jerk. State the move duration and final position; slowing the reference changes the task and should be visible in comparisons. Verify the actuator demand using the actual inner-loop dynamics rather than the reference shape alone.