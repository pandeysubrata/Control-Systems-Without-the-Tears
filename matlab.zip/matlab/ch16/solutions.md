# Chapter 16: exercise guidance

The typeset version is in Appendix D of the book. Mathematical notation is retained below.

## Exercise 1

For $x^+=ax+bu$ and $y=cx$, $F=[ca,ca^2,ca^3]^T$ and $G=[cb,0,0;cab,cb,0;ca^2b,cab,cb]$. These rows predict the next three outputs, not the current output. With a nonzero direct-feedthrough term the formula needs modification; the companion assumes none.

## Exercise 2

Let $e_0=Fx-r$. Expanding $(e_0+GU)^TQ(e_0+GU)+(U-U_s)^TR(U-U_s)$ gives quadratic term $U^T(G^TQG+R)U$ and linear term $2U^T(G^TQe_0-RU_s)$. Thus $H=2(G^TQG+R)$ and $f=2(G^TQe_0-RU_s)$. Terms independent of $U$ do not affect the optimizer.

## Exercise 3

New measurements arrive before the next decision, changing the estimated state and possibly the reference or disturbance estimate. Applying only the first move allows the next optimization to use that information. The remaining sequence is a conditional plan and a useful warm start, not an irrevocable command schedule.

## Exercise 4

Use a nonzero initial state and a nonconstant input vector. Propagate $x_{j+1}=Ax_j+Bu_j$ and store $Cx_{j+1}$. Compare the resulting vector with $Fx_0+GU$. A near-roundoff difference checks algebraic indexing for that model. It does not validate the physical plant or the optimizer.

## Exercise 5

With state $[x,q_1,q_2,q_3]^T$, use $x^+=ax+bq_3$, $q_1^+=u$, $q_2^+=q_1$ and $q_3^+=q_2$. The queued values must be initialized consistently with prior actuator history. Starting the queue at zero assumes no pending heat input at the beginning of the simulation.

## Exercise 6

A scheduled reference supplied by the operator is available information and may be included in the horizon. A future unmeasured disturbance is unavailable unless a declared forecast provides it. Giving only one controller the exact future disturbance changes the information structure and can create a misleading benchmark advantage.