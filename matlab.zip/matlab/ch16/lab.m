%% Extended investigation: Audit predictions before optimizing them
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
a=exp(-2/80); b=2*(1-a); [A,B,C]=delayPlant(a,b,3);
N=8; [F,G]=predictionMatrices(A,B,C,N);
x=[0.2;0.4;0.1;0.7]; U=[0.8;0.3;0;1;0.6;0.2;0.9;0.5];
matrixPrediction=F*x+G*U;
direct=zeros(N,1); state=x;
for j=1:N
    state=A*state+B*U(j);
    direct(j)=C*state;
end
error=matrixPrediction-direct;
disp('Step, direct prediction, matrix prediction, discrepancy');
disp([(1:N)' direct matrixPrediction error]);
fprintf('Largest discrepancy: %g\n',norm(error,Inf));
assert(norm(error,Inf)<1e-12);
imagesc(G); colorbar; xlabel('Future input index');
ylabel('Predicted output index'); title('Input-delay structure in G');
% Change the queue length and repeat this exact audit.
% Confirm which future output first depends on the new input.
