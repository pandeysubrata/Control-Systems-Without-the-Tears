%% Chapter 16: short experiment
% Intended as a short run; actual timing depends on MATLAB and hardware.
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
% Input-constrained predictive control of a normalized thermal plant.
Ts=2; a=exp(-Ts/80); b=2*(1-a); d=3;
[A,B,C]=delayPlant(a,b,d); Np=20;
[F,G]=predictionMatrices(A,B,C,Np);
model=struct('F',F,'G',G,'Q',eye(Np),'R',0.02*eye(Np), ...
             'N',Np,'lo',0,'hi',1,'uref',0.5);
x=zeros(size(A,1),1); mem=[]; Nsim=100; y=zeros(1,Nsim); u=y;
worstResidual=0;
for k=1:Nsim
    y(k)=C*x; [u(k),mem,info]=simpleMPC(x,1,model,mem);
    worstResidual=max(worstResidual,info.residual);
    x=A*x+B*u(k);
end
plotPair((0:Nsim-1)*Ts,40*y,100*u,40,'Thermal input-box MPC');
fprintf('Largest projected QP residual: %g\n',worstResidual);
% Output in deg C above ambient; command in percent heater duty.
