%% Extended investigation: Continuous feedback and held feedback are different experiments
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
m=bookModels(); intervals=[0.01 0.03 0.06]; figure;
for Ts=intervals
    [A,B]=zohExact(m.cart.A,m.cart.B,Ts);
    [K,~,~]=riccatiDiscrete(A,B,diag([10 1 150 2]),0.1);
    x=[0;0;10*pi/180;0]; N=ceil(4/Ts); Y=zeros(4,N);
    U=zeros(1,N); opts=odeset('RelTol',1e-7,'AbsTol',1e-9);
    for k=1:N
        Y(:,k)=x; u=min(8,max(-8,-K*x)); U(k)=u;
        held=@(time,state) cartDynamics(time,state,u,m.cart);
        [~,segment]=ode45(held,[0 Ts],x,opts);
        x=segment(end,:)';
    end
    subplot(2,1,1); hold on;
    plot((0:N-1)*Ts,Y(3,:)*180/pi,'DisplayName',num2str(Ts));
    subplot(2,1,2); hold on; plot((0:N-1)*Ts,U);
end
subplot(2,1,1); ylabel('Angle (degrees)'); legend('Ts');
subplot(2,1,2); ylabel('Force (N)'); xlabel('Time (s)');
% Tighten ODE tolerances at one fixed Ts as a separate check.
