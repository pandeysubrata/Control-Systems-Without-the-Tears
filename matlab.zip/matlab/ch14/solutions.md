# Chapter 14: exercise guidance

The typeset version is in Appendix D of the book. Mathematical notation is retained below.

## Exercise 1

For the ideal directly actuated equation $\ddot\theta=(g/l)\sin\theta+u_a$, choose $u_a=-(g/l)\sin\theta+v$. Then $\ddot\theta=v$. Taking $v=-k_1\theta-k_2\dot\theta$ gives a linear second-order error equation. The cancellation requires the stated input channel, model parameters and available actuation.

## Exercise 2

At 20 degrees, $\theta\approx0.349066$ and $\sin\theta\approx0.342020$. Relative to the exact sine value, the approximation error is $(\theta-\sin\theta)/\sin\theta\approx2.06$ percent. Relative to the linear value it is about 2.02 percent. State the denominator; otherwise two correct calculations can appear inconsistent.

## Exercise 3

Cart force first affects cart acceleration, which couples into angular acceleration through geometry and state-dependent terms. It is not identical to a directly commanded angular acceleration. Substituting force into the ideal cancellation formula ignores input gain, units and coupling. Derive the actual input-output dynamics before attempting feedback linearization.

## Exercise 4

At each sample, calculate one command from the current measured or estimated state. Integrate the nonlinear plant over the sample interval with that command fixed, then update the controller again. Keep ODE tolerances and controller sample time separate. Compare against the continuously recomputed-feedback case with the distinction clearly labeled.

## Exercise 5

Ideal switching can generate chattering when unmodeled dynamics, sampling and finite actuator bandwidth interact with the discontinuous command. Replacing the sign function with a boundary layer smooths the command but generally sacrifices exact sliding behavior and may permit a residual error. The acceptable trade-off depends on the plant and disturbance assumptions.

## Exercise 6

Vary declared initial angles and velocities, then record peak angle, peak cart position, peak force and final tolerances. Mark a case failed when any required bound is violated, even if the pole later returns upright. The map applies only to the tested initial-condition family and uncertainty assumptions; it is not a global region-of-attraction proof.