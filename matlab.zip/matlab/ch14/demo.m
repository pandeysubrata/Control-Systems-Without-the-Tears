%% Chapter 14: short experiment
% Intended as a short run; actual timing depends on MATLAB and hardware.
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
% Compare a pendulum's nonlinear restoring acceleration with a local line.
ell=0.3; g=9.81; angles=linspace(-pi/2,pi/2,200);
figure; plot(angles*180/pi,g/ell*sin(angles), ...
             angles*180/pi,g/ell*angles,'--');
xlabel('Upright angle (deg)'); ylabel('Free angular acceleration (rad/s^2)');
legend('Nonlinear','Linearized'); grid on;
m=bookModels(); Ts=0.01; [A,B]=zohExact(m.cart.A,m.cart.B,Ts);
[K,~,~]=riccatiDiscrete(A,B,diag([10 1 150 2]),0.1);
x0=[0;0;10*pi/180;0]; forceLimit=8;
f=@(t,x) cartDynamics(t,x,min(forceLimit,max(-forceLimit,-K*x)),m.cart);
[t,X]=ode45(f,[0 5],x0);
figure; plot(t,X(:,3)*180/pi); xlabel('Time (s)'); ylabel('Lean (deg)');
% This is continuous state feedback in an ODE, not a sampled implementation.
