%% Extended investigation: Metrics that refuse to hide an offset
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
taus=[0.5 2]; finalGains=[1 0.9]; grids=[0.1 0.01];
report=[];
for Ts=grids
    t=(0:Ts:12)';
    for tau=taus
        for gain=finalGains
            y=gain*(1-exp(-t/tau));
            s=stepMetrics(t,y,1,0);
            report(end+1,:)=[Ts tau gain s.rise ...
                s.settling s.overshoot s.finalError]; %#ok<AGROW>
        end
    end
end
disp('Ts, tau, final gain, rise, target settling, overshoot, end error');
disp(report);
t=(0:0.01:12)';
plot(t,1-exp(-t/2),t,0.9*(1-exp(-t/2)));
hold on; plot(t,1.02+0*t,':',t,0.98+0*t,':');
xlabel('Time (s)'); ylabel('Output');
legend('Correct final value','10 percent offset','Upper band','Lower band');
% An NaN settling time is an explicit missing achievement.
% It must not silently become zero in a comparison table.
