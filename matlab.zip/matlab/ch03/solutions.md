# Chapter 3: exercise guidance

The typeset version is in Appendix D of the book. Mathematical notation is retained below.

## Exercise 1

The unit-step response is $1-e^{-t/2}$. Requiring $e^{-t/2}\leq0.02$ gives $t\geq-2\log(0.02)=7.82405$ s. This exact first-order result is slightly smaller than the common four-time-constant approximation of eight seconds. The definition is relative to the unit final change and assumes an ideal continuous response without noise.

## Exercise 2

The poles are $-\zeta\omega_n\pm j\omega_n\sqrt{1-\zeta^2}=-2\pm j\sqrt{12}$. The standard zero-free second-order overshoot is $100e^{-\pi\zeta/\sqrt{1-\zeta^2}}\approx16.30$ percent. Numerator zeros, additional modes and saturation can make this formula a poor predictor even when a pair of poles has the same damping ratio.

## Exercise 3

A response tending to 0.9 can remain close to 0.9 while never entering a two-percent band around one. A final-value-based settling metric and a target-based settling metric answer different questions. State the band center and width in the report. The companion returns an unachieved target-based settling time as NaN rather than disguising it as successful settling.

## Exercise 4

Run the same continuous model on both grids, keeping the observation duration unchanged. Compare the sampled 10 and 90 percent crossing times. The companion uses the first sample meeting each threshold, so its result has grid-dependent quantization. A finer grid should reduce this numerical discrepancy; it does not necessarily change the underlying continuous response or remove model error.

## Exercise 5

The pole 0.8 gives monotone modal decay. The pole $-0.8$ decays while alternating sign each sample. The pole 1.02 grows and is unstable. The complex pole $0.9e^{j0.4}$ has decaying magnitude and an oscillatory phase increment of 0.4 radians per sample; a real model includes its conjugate. Discrete stability depends on magnitude, not real-part sign.

## Exercise 6

An unstable internal mode can be hidden by a pole-zero cancellation in an input-output transfer function. A finite-duration step response can also miss a slow instability or a mode weakly excited by that input and initial condition. Inspect the internal model, relevant initial conditions and other signal paths. A good-looking trace is evidence for that experiment, not a universal internal-stability proof.