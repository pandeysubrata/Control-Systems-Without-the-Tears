%% Chapter 03: short experiment
% Intended as a short run; actual timing depends on MATLAB and hardware.
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
% Damping changes the journey even when the final value stays one.
t=(0:0.005:8)'; wn=3; zetas=[0.2 0.7 1.2];
figure; hold on;
for zeta=zetas
    A=[0 1;-wn^2 -2*zeta*wn]; B=[0;wn^2];
    [Ad,Bd]=zohExact(A,B,t(2)-t(1));
    y=simDiscrete(Ad,Bd,[1 0],0,ones(1,numel(t)),[0;0]);
    plot(t,y,'LineWidth',1.3);
    s=stepMetrics(t,y,1,0); disp(s);
    fprintf('Damping %.2f, poles:\n',zeta); disp(eig(A));
end
xlabel('Time (s)'); ylabel('Normalized output');
legend('zeta=0.2','zeta=0.7','zeta=1.2'); grid on;
% Overshoot formula applies only to the underdamped standard second-order form.
