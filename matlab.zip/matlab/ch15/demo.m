%% Chapter 15: short experiment
% Intended as a short run; actual timing depends on MATLAB and hardware.
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
% One tiny QP, two independent solution routes.
H=[4 1;1 2]; f=[-3;-2]; lb=[0;0]; ub=[1;1];
[x,info]=boxQP(H,f,lb,ub,[0;0],3000,1e-10);
J=@(z) 0.5*z'*H*z+f'*z;
fprintf('x=[%.6f %.6f], J=%.8f\n',x(1),x(2),J(x)); disp(info);
if exist('quadprog','file')==2
    o=optimoptions('quadprog','Display','off');
    xt=quadprog(H,f,[],[],[],[],lb,ub,[],o);
    fprintf('Toolbox difference: %.3g\n',norm(x-xt));
end
% For this data the unconstrained solution lies inside the box.
disp(-H\f);
