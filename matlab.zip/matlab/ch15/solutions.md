# Chapter 15: exercise guidance

The typeset version is in Appendix D of the book. Mathematical notation is retained below.

## Exercise 1

Compute $Hx+f$ with $H=[4,1;1,2]$, $f=[-3,-2]^T$ and $x=[4/7,5/7]^T$; both components are zero. The Hessian is positive definite because its leading principal minors are four and seven. The point lies inside the unit box, so it is the unique constrained minimizer as well as the unconstrained one.

## Exercise 2

At the active bound $x_1=0.4$, stationarity in $x_2$ gives $0.4+2x_2-2=0$, so $x_2=0.8$. The first gradient component is minus 0.6, consistent with wanting to increase a variable already at its upper bound. The second is zero. Thus the unique minimizer is $[0.4,0.8]^T$.

## Exercise 3

Positive definiteness determines the curvature of the objective, not whether the constraint set contains a point. For example, requiring simultaneously $x\leq0$ and $x\geq1$ is infeasible for any Hessian. A solver must distinguish an infeasible problem from a feasible problem that it has not solved accurately enough.

## Exercise 4

Assuming symmetric $M$, compare with $\tfrac12z^THz+f^Tz$: use $H=2M$ and $f=2q$. If $M$ is not symmetric, only its symmetric part contributes to the quadratic form. Missing the factor of two in only one term changes the optimizer; multiplying the entire objective by a positive constant does not.

## Exercise 5

Clipping gives $[0.4,5/7]^T$, while the constrained solution is $[0.4,0.8]^T$. Coupling through the off-diagonal Hessian term means changing the first coordinate changes the best second coordinate. Evaluate both objectives and gradients. Componentwise clipping is exact only for special separable structures, not for a general coupled quadratic.

## Exercise 6

Require finite values, acceptable constraint residuals, an acceptable optimality residual and completion before the deadline. Define tolerances in scaled units. On failure, use a specified feasible command or backup controller and log the reason. A finite returned vector or a small objective alone is not enough to accept an online optimizer's output.