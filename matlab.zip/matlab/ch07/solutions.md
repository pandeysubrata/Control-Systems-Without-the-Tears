# Chapter 7: exercise guidance

The typeset version is in Appendix D of the book. Mathematical notation is retained below.

## Exercise 1

At $K=0.25$, roots are $-1\pm\sqrt{0.75}$, approximately $-0.133975$ and $-1.866025$. At $K=1$, both roots are minus one. At $K=4$, roots are $-1\pm j\sqrt3$. The repeated-root case is the boundary between two real roots and a complex pair, not an instability boundary.

## Exercise 2

Compare $s^2+2s+K$ with $s^2+2\zeta\omega_ns+\omega_n^2$. Then $\omega_n=\sqrt K$ and $\zeta=1/\sqrt K$. For $K>1$ the pair is underdamped. The oscillation frequency is $\sqrt{K-1}$ while the exponential envelope decays at rate one.

## Exercise 3

The quadratic formula gives $s=-1\pm\sqrt{1-K}$. Once $K>1$, the square-root term is purely imaginary. Its real part is zero, leaving both real parts fixed at minus one. Increasing gain therefore increases oscillation frequency without making the exponential envelope decay faster in this particular example.

## Exercise 4

For loop $K(s+3)/[s(s+2)]$, use roots of $s^2+(2+K)s+3K$. The added zero changes both the sum and product of the roots. Plot dots or track branches carefully because numerical root ordering can swap. Also note that this ideal controller contains differentiation and needs a realizable high-frequency roll-off for implementation.

## Exercise 5

The standard formula assumes a dominant underdamped second-order pair and a numerator whose zeros do not substantially distort the response. It also assumes the linear unsaturated model describes the experiment. Additional slow modes, significant zeros, delay or actuator clipping can break the correspondence between pole damping ratio and observed reference overshoot.

## Exercise 6

Root locus follows the characteristic roots of a linear loop as gain varies. Saturation makes the closed-loop law nonlinear and changes the effective command. A design with attractive nominal poles may have a large initial request, prolonged clipping or poor recovery. Test the requested and applied commands alongside the output before interpreting the locus as a complete design.