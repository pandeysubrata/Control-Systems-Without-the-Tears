%% Chapter 07: short experiment
% Intended as a short run; actual timing depends on MATLAB and hardware.
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
% Characteristic equation: s^2+2s+K=0 for P(s)=1/[s(s+2)].
K=linspace(0,12,250); poles=zeros(2,numel(K));
for k=1:numel(K), poles(:,k)=roots([1 2 K(k)]); end
figure; plot(real(poles.'),imag(poles.'),'.');
xlabel('Real part (1/s)'); ylabel('Imaginary part (rad/s)');
axis equal; grid on;
Kchosen=4; p=roots([1 2 Kchosen]); disp(p);
% Under this exact second-order model, wn=sqrt(K), zeta=1/sqrt(K).
if exist('tf','file')==2
    G=tf(1,[1 2 0]); figure; rlocus(G); grid on;
end
