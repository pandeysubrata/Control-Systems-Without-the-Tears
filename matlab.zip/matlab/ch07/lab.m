%% Extended investigation: What one added zero really changes
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
gains=linspace(0,12,301);
original=zeros(2,numel(gains)); withZero=original;
for k=1:numel(gains)
    K=gains(k);
    original(:,k)=roots([1 2 K]);
    withZero(:,k)=roots([1 2+K 3*K]);
end
subplot(1,2,1);
plot(real(original),imag(original),'.');
xlabel('Real part'); ylabel('Imaginary part'); title('Original'); grid on;
subplot(1,2,2);
plot(real(withZero),imag(withZero),'.');
xlabel('Real part'); ylabel('Imaginary part'); title('Zero at -3'); grid on;
selected=[0.25 1 4];
for K=selected
    fprintf('Gain %g: original roots\n',K); disp(roots([1 2 K]));
    fprintf('Gain %g: new roots\n',K); disp(roots([1 2+K 3*K]));
end
% The branches can change root ordering between adjacent gains.
% This is why dots, rather than connected root indices, are used.
% A practical differentiating compensator also needs a pole.
