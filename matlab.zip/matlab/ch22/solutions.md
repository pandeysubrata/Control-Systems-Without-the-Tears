# Chapter 22: exercise guidance

The typeset version is in Appendix D of the book. Mathematical notation is retained below.

## Exercise 1

Hover requires total upward thrust equal to weight, $T=mg=1.2(9.81)=11.772$ N at zero tilt in the simplified model. This is total thrust, not thrust per rotor. A symmetric four-rotor allocation would nominally divide it by four, subject to the actual geometry and propulsion model.

## Exercise 2

The multiplier is $1/\cos\phi$. At 20 degrees it is approximately 1.06418; at 45 degrees it is $\sqrt2\approx1.41421$. This compensates the static vertical component only. Additional thrust is needed for upward acceleration, and real allocation limits may prevent the requested combination of thrust and torque.

## Exercise 3

An accelerometer measures specific force, which includes the effects of vehicle acceleration as well as the gravity-related orientation signal under appropriate conditions. During maneuvering, treating its vector as pure gravity can produce an incorrect attitude estimate. Sensor fusion uses a motion model and complementary information, such as gyro measurements, with stated assumptions.

## Exercise 4

Add a thrust state satisfying $\tau_T\dot T_a=-T_a+T_c$ and use $T_a$ in the vertical acceleration equation. Keep the command limits and controller unchanged for the first comparison. The lag adds dynamics and phase loss, so altitude transients may worsen. Test more than one lag value and distinguish retuning from the original comparison.

## Exercise 5

Keep the controller update schedule fixed if the aim is to test integration accuracy; use substeps inside each held-command interval. If the controller also updates twice as often, the experiment changes both numerics and implementation. Compare peak and final quantities, not just visually overlapping plots.

## Exercise 6

Rotor forces jointly determine total thrust and torques through a mixing matrix. A feasible pair of independent scalar bounds may still require one rotor to generate negative thrust or exceed its maximum. Check the allocated rotor commands and handle allocation saturation explicitly. The simplified independent limits do not certify a realizable multirotor command.