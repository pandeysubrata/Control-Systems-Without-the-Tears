%% Extended investigation: Tilt compensation spends thrust reserve
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
mass=1.2; g=9.81; maxThrust=2*mass*g;
angles=0:0.5:75; phi=angles*pi/180;
required=mass*g./cos(phi);
applied=min(maxThrust,required);
vertical=applied.*cos(phi);
reserve=maxThrust-required;
subplot(2,1,1); plot(angles,required,angles,applied,'--');
ylabel('Total thrust (N)'); legend('Required','Available command');
subplot(2,1,2); plot(angles,vertical/(mass*g));
xlabel('Roll angle (degrees)'); ylabel('Vertical force / weight');
critical=acos(mass*g/maxThrust)*180/pi;
fprintf('Ideal static tilt limit at this thrust bound: %.3g degrees\n',critical);
for angle=[20 45 60]
    multiplier=1/cos(angle*pi/180);
    fprintf('%g degrees: thrust multiplier %.4g\n',angle,multiplier);
end
% A zero static reserve leaves no authority for upward acceleration.
% The simplified calculation is not a flight-envelope certification.
