%% Chapter 22: short experiment
% Intended as a short run; actual timing depends on MATLAB and hardware.
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
% Simplified roll/altitude: no yaw, pitch, motor lag or translational aerodynamics.
Ts=0.005; t=0:Ts:10; mass=1.2; Ix=0.02; g=9.81;
phi=0; rate=0; z=0; vz=0; I=0; Z=zeros(size(t)); PHI=Z; thrust=Z;
for k=1:numel(t)
    phir=0.1*(t(k)>2 & t(k)<5); pr=4*(phir-phi);
    torque=min(0.25,max(-0.25,0.08*(pr-rate)));
    vr=min(1,max(-1,1.5*(1-z))); err=vr-vz;
    raw=mass*(g+2*err+I); T=min(2*mass*g,max(0,raw));
    I=I+Ts*(0.6*err+2*(T-raw)/mass);
    Z(k)=z; PHI(k)=phi; thrust(k)=T;
    rate=rate+Ts*torque/Ix; phi=phi+Ts*rate;
    vz=vz+Ts*(T*cos(phi)/mass-g); z=z+Ts*vz;
end
figure; subplot(3,1,1); plot(t,Z); ylabel('Altitude (m)');
subplot(3,1,2); plot(t,PHI*180/pi); ylabel('Roll (deg)');
subplot(3,1,3); plot(t,thrust); ylabel('Thrust (N)'); xlabel('Time (s)');
% Educational simulation only; this is not a flight controller.
