# Chapter 21: exercise guidance

The typeset version is in Appendix D of the book. Mathematical notation is retained below.

## Exercise 1

At upright and zero velocity, $\ddot p\approx u/M-(b/M)\dot p-(mg/M)\theta$. Also $\ddot\theta\approx[(M+m)g/(Ml)]\theta+[b/(Ml)]\dot p-u/(Ml)$. Hence the force column is $[0,1/M,0,-1/(Ml)]^T$. Positive cart acceleration initially produces negative angular acceleration in the stated angle convention.

## Exercise 2

With $M=0.5$ kg and $l=0.3$ m, one newton at upright from rest gives cart acceleration $1/M=2$ m/s$^2$ and angular acceleration $-1/(Ml)=-6.66667$ rad/s$^2$. This checks the input signs independently of an LQR calculation. A different angle convention would require corresponding sign changes throughout the model.

## Exercise 3

Use the same initial true state, force limit, noise record and nonlinear plant. The ideal-state case omits estimation error; the estimated-state case includes it. Compare force, cart travel and angle as well as the state-estimation error. The difference measures the selected estimator and sensing assumptions, not only the feedback gain.

## Exercise 4

Represent the delay explicitly in the measurement path or augmented estimator model. Do not simply relabel timestamps while supplying the current state. Compare the response with unchanged gains first, then consider redesign as a separate experiment. A delayed measurement may require prediction from the measurement time to the actuation time.

## Exercise 5

Grid initial lean and, if relevant, initial velocity. Require both angle recovery and cart-travel bounds, with force limits applied. Mark cases that leave the permitted envelope as failures even if a later unconstrained simulation returns upright. Include the grid resolution and tested duration; the map is finite evidence, not a global proof.

## Exercise 6

The local controller is designed around upright and tested over selected initial conditions. Swing-up from the hanging position is a different nonlinear maneuver. Hardware safety also depends on sensors, rails, motors, timing, mechanical stops and independent protection. None of those is established by a successful local numerical simulation.