%% Chapter 21: short experiment
% Intended as a short run; actual timing depends on MATLAB and hardware.
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
% Sampled nonlinear plant, estimated state, bounded cart force.
rng(21,'twister'); m=bookModels(); Ts=0.01;
[A,B]=zohExact(m.cart.A,m.cart.B,Ts); C=m.cart.C;
[K,~,~]=riccatiDiscrete(A,B,diag([10 1 150 2]),0.1);
Q=diag([1e-7 1e-5 1e-7 1e-5]); R=diag([1e-5 1e-5]);
x=[0;0;4*pi/180;0]; xh=zeros(4,1); P=0.1*eye(4); u=0;
count=400; truth=zeros(4,count); estimate=truth; U=zeros(1,count);
for k=1:count
    % Correct the estimate using the current measurement before choosing u.
    y=C*x+chol(R,'lower')*randn(2,1);
    S=C*P*C'+R; L=(P*C')/S; xh=xh+L*(y-C*xh);
    E=eye(4)-L*C; P=E*P*E'+L*R*L';
    u=min(8,max(-8,-K*xh)); truth(:,k)=x; estimate(:,k)=xh; U(k)=u;
    [~,sol]=ode45(@(t,z) cartDynamics(t,z,u,m.cart),[0 Ts],x);
    x=sol(end,:)'; xh=A*xh+B*u; P=A*P*A'+Q;
end
figure; plot((0:count-1)*Ts,[truth(3,:);estimate(3,:)]'*180/pi);
xlabel('Time (s)'); ylabel('Lean (deg)'); legend('True','Estimated');
% Hardware rail/end-stop protection is not modeled by this script.
