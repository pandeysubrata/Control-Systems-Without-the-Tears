%% Extended investigation: Recovery includes the cart, not only the pole
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
m=bookModels(); Ts=0.01;
[A,B]=zohExact(m.cart.A,m.cart.B,Ts);
[K,~,~]=riccatiDiscrete(A,B,diag([10 1 150 2]),0.1);
angles=[2 5 10 15 20]; results=zeros(numel(angles),5);
opts=odeset('RelTol',1e-6,'AbsTol',1e-8);
for j=1:numel(angles)
    x=[0;0;angles(j)*pi/180;0]; maxAngle=abs(x(3)); maxTravel=0;
    maxForce=0; failed=false;
    for k=1:500
        u=min(8,max(-8,-K*x));
        [~,segment]=ode45(@(time,state) ...
            cartDynamics(time,state,u,m.cart),[0 Ts],x,opts);
        x=segment(end,:)';
        maxAngle=max(maxAngle,abs(x(3)));
        maxTravel=max(maxTravel,abs(x(1))); maxForce=max(maxForce,abs(u));
        if abs(x(3))>pi/2 || abs(x(1))>0.5
            failed=true; break;
        end
    end
    results(j,:)=[angles(j) maxAngle*180/pi maxTravel maxForce failed];
end
disp('Initial degrees, peak degrees, peak travel m, peak N, envelope failure');
disp(results);
% Stopping at the declared envelope is a failed test, not recovery.
