% Control Systems Without the Tears -- educational companion.
function [A,B,C] = delayPlant(a,b,d)
%DELAYPLANT y(k+1)=a*y(k)+b*u(k-d). d integer >=0.
assert(d>=0 && d==floor(d));
if d==0, A=a; B=b; C=1; return; end
A=zeros(d+1); A(1,1)=a; A(1,end)=b;
for j=3:d+1, A(j,j-1)=1; end
B=zeros(d+1,1); B(2)=1; C=[1 zeros(1,d)];
end
