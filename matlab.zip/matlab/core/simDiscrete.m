% Control Systems Without the Tears -- educational companion.
function [Y,X] = simDiscrete(A,B,C,D,U,x0)
%SIMDISCRETE U is nu-by-N. Y(:,k) uses x(k) before applying U(:,k).
x=x0(:); N=size(U,2); X=zeros(numel(x),N+1);
Y=zeros(size(C,1),N); X(:,1)=x;
for k=1:N
    Y(:,k)=C*x+D*U(:,k);
    x=A*x+B*U(:,k); X(:,k+1)=x;
end
end
