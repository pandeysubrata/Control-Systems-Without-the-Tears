% Control Systems Without the Tears -- educational companion.
function s = pidInit(y,u,r,p)
%PIDINIT Match a desired current output on transfer, with zero derivative state.
s.d=0; s.yprev=y; s.I=u-p.Kp*(p.beta*r-y);
end
