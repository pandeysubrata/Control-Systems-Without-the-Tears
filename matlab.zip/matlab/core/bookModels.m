% Control Systems Without the Tears -- educational companion.
function m = bookModels()
%BOOKMODELS Fixed synthetic teaching models; SI units unless stated.
m.motor.J=0.02; m.motor.b=0.04; m.motor.K=0.08;
m.motor.R=2; m.motor.L=0.02;
m.motor.A=[-100 -4;4 -2]; m.motor.B=[50;0];
m.motor.C=[0 1]; m.motor.D=0;
m.motor.Kdc=1/1.08; m.motor.tau=1/2.16;
m.mass.A=[0 1;-4 -1.2]; m.mass.B=[0;1];
m.mass.C=[1 0]; m.mass.D=0;
M=0.5; mp=0.2; ell=0.3; b=0.05; g=9.81;
m.cart.M=M; m.cart.m=mp; m.cart.l=ell; m.cart.b=b;
m.cart.A=[0 1 0 0;0 -b/M -mp*g/M 0; ...
          0 0 0 1;0 b/(M*ell) (M+mp)*g/(M*ell) 0];
m.cart.B=[0;1/M;0;-1/(M*ell)];
m.cart.C=[1 0 0 0;0 0 1 0]; m.cart.D=zeros(2,1);
m.thermal.tau=80; m.thermal.gain=80; m.thermal.delay=6;
m.thermal.ambient=20; m.thermal.Ts=2;
m.drone.mass=1.2; m.drone.Ix=0.02; m.drone.g=g;
end
