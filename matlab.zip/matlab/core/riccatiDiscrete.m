% Control Systems Without the Tears -- educational companion.
function [K,P,info] = riccatiDiscrete(A,B,Q,R)
%RICCATIDISCRETE DARE fixed-point iteration: teaching stabilizable systems.
% Requires Q>=0, R>0 and suitable detectability; fails visibly otherwise.
n=size(A,1); assert(all(size(Q)==[n n]));
assert(min(eig((Q+Q')/2))>=-1e-10 && min(eig((R+R')/2))>0);
P=Q; converged=false;
for k=1:20000
    G=R+B'*P*B; K=G\(B'*P*A);
    Pn=Q+A'*P*A-A'*P*B*K; Pn=(Pn+Pn')/2;
    if norm(Pn-P,'fro')<=1e-11*max(1,norm(Pn,'fro'))
        P=Pn; converged=true; break;
    end
    P=Pn;
end
K=(R+B'*P*B)\(B'*P*A);
res=Q+A'*P*A-A'*P*B*K-P;
info=struct('iterations',k,'converged',converged, ...
            'residual',norm(res,'fro'),'radius',max(abs(eig(A-B*K))));
assert(converged && info.radius<1,'DARE solve did not yield a stable solution.');
end
