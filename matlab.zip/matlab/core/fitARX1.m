% Control Systems Without the Tears -- educational companion.
function [a,b,res] = fitARX1(u,y)
%FITARX1 ARX y(k+1)=a*y(k)+b*u(k)+e(k+1), zero offsets assumed removed.
u=u(:); y=y(:); assert(numel(u)==numel(y));
Phi=[y(1:end-1) u(1:end-1)]; target=y(2:end);
assert(rank(Phi)==2,'Experiment does not identify both coefficients.');
theta=Phi\target; a=theta(1); b=theta(2); res=target-Phi*theta;
end
