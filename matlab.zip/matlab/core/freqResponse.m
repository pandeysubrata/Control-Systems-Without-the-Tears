% Control Systems Without the Tears -- educational companion.
function H = freqResponse(A,B,C,D,w,Ts)
%FREQRESPONSE Continuous if Ts omitted/zero, discrete otherwise.
if nargin<6, Ts=0; end
assert(size(B,2)==1 && size(C,1)==1,'Teaching SISO interface.');
H=zeros(size(w)); I=eye(size(A));
for k=1:numel(w)
    if Ts==0, z=1i*w(k); else, z=exp(1i*w(k)*Ts); end
    H(k)=C*((z*I-A)\B)+D;
end
end
