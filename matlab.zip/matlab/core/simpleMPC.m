% Control Systems Without the Tears -- educational companion.
function [u,mem,info] = simpleMPC(x,r,model,mem)
%SIMPLEMPC SISO input-box MPC. No automatic state-constraint guarantee.
% model: F,G,Q,R,N,lo,hi,uref. r: scalar or N-vector.
N=model.N; if isscalar(r), r=repmat(r,N,1); end
Q=model.Q; R=model.R;
H=2*(model.G'*Q*model.G+R);
f=2*(model.G'*Q*(model.F*x-r)-R*repmat(model.uref,N,1));
if isempty(mem), U=repmat(model.uref,N,1);
else, U=[mem(2:end);mem(end)]; end
[U,info]=boxQP(H,f,repmat(model.lo,N,1), ...
             repmat(model.hi,N,1),U,1500,1e-7);
u=U(1); mem=U;
end
