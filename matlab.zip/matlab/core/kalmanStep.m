% Control Systems Without the Tears -- educational companion.
function [xh,P,innovation,S] = kalmanStep(xh,P,u,y,A,B,C,Q,R)
%KALMANSTEP Predict from k-1 using u(k-1), then correct with measurement y(k).
xp=A*xh+B*u; Pp=A*P*A'+Q;
innovation=y-C*xp; S=C*Pp*C'+R;
L=(Pp*C')/S; xh=xp+L*innovation;
I=eye(size(P)); E=I-L*C;
P=E*Pp*E'+L*R*L'; P=(P+P')/2; % Joseph covariance update
end
