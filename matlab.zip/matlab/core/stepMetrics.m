% Control Systems Without the Tears -- educational companion.
function s = stepMetrics(t,y,target,initial)
%STEPMETRICS Explicit target-based metrics, not an imitation of every stepinfo option.
t=t(:); y=y(:); amplitude=target-initial;
assert(numel(t)==numel(y) && numel(t)>1 && amplitude~=0);
z=(y-initial)/amplitude; s.finalError=target-y(end);
s.overshoot=100*max(0,max(z)-1);
i10=find(z>=0.1,1); i90=find(z>=0.9,1);
s.rise=NaN; if ~isempty(i10) && ~isempty(i90), s.rise=t(i90)-t(i10); end
bad=find(abs(z-1)>0.02); s.settling=NaN;
if isempty(bad), s.settling=t(1);
elseif bad(end)<numel(t), s.settling=t(bad(end)+1); end
s.IAE=trapz(t,abs(target-y));
% A finite record cannot prove that the response stays settled forever.
end
