% Control Systems Without the Tears -- educational companion.
function [u,s,v] = pidStep(r,y,s,p)
%PIDSTEP Filtered derivative on measurement; output-unit integral state.
% p: Kp,Ki,Kd,Tf,Ts,beta,lo,hi,Kaw. s: I,d,yprev.
assert(p.Ts>0 && p.Tf>0 && p.lo<p.hi);
a=p.Tf/(p.Tf+p.Ts);
s.d=a*s.d+(1-a)*(y-s.yprev)/p.Ts;
v=p.Kp*(p.beta*r-y)+s.I-p.Kd*s.d;
u=min(p.hi,max(p.lo,v));
s.I=s.I+p.Ts*(p.Ki*(r-y)+p.Kaw*(u-v));
s.yprev=y;
end
