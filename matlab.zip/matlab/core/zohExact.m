% Control Systems Without the Tears -- educational companion.
function [Ad,Bd] = zohExact(A,B,Ts)
%ZOHEXACT Exact ZOH using an augmented matrix exponential, even if A singular.
n=size(A,1); nu=size(B,2);
assert(size(A,2)==n && size(B,1)==n && Ts>0);
E=expm([A B;zeros(nu,n+nu)]*Ts);
Ad=E(1:n,1:n); Bd=E(1:n,n+1:n+nu);
end
