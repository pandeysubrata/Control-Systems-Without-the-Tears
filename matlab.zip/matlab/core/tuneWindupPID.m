function result=tuneWindupPID(a,b,p,candidates)
%TUNEWINDUPPID Educational grid search for a declared scalar recovery test.
% Plant: y(k+1)=a*y(k)+b*u(k). p contains the pidStep parameters.
% This chooses Kaw only; it is not an automatic general PID designer.
assert(abs(a)<1 && b>0 && p.lo==0 && p.hi==1);
N=ceil(12/p.Ts); t=(0:N-1)*p.Ts;
reference=0.5+1.5*(t<5); scores=zeros(size(candidates));
for j=1:numel(candidates)
    q=p; q.Kaw=candidates(j); s=pidInit(0,0,0,q); y=0;
    output=zeros(1,N);
    for k=1:N
        output(k)=y;
        [u,s]=pidStep(reference(k),y,s,q);
        y=a*y+b*u;
    end
    selected=t>=5;
    scores(j)=trapz(t(selected),abs(reference(selected)-output(selected)));
end
[best,index]=min(scores);
result=struct('Kaw',candidates(index),'score',best, ...
    'candidates',candidates,'scores',scores, ...
    'scenario','Reference 2 until 5 s, then 0.5; recovery IAE through 12 s');
end
