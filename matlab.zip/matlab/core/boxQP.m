% Control Systems Without the Tears -- educational companion.
function [x,info] = boxQP(H,f,lb,ub,x,maxit,tol)
%BOXQP Projected gradient for strictly convex box QP, no general inequalities.
H=(H+H')/2; eigenvalues=eig(H);
assert(min(eigenvalues)>0,'H must be positive definite.');
alpha=1/max(eigenvalues); x=min(ub,max(lb,x));
res=Inf;
for k=1:maxit
    xn=min(ub,max(lb,x-alpha*(H*x+f)));
    res=norm(x-xn,Inf)/alpha; x=xn;
    if res<tol, break; end
end
info=struct('iterations',k,'residual',res,'converged',res<tol);
end
