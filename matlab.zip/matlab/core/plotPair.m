% Control Systems Without the Tears -- educational companion.
function plotPair(t,y,u,r,caption)
figure('Name',caption);
subplot(2,1,1); plot(t,y,'LineWidth',1.4); hold on;
if isscalar(r), plot(t,0*t+r,'--'); else, plot(t,r,'--'); end
xlabel('Time (s)'); ylabel('Output'); legend('Output','Reference'); grid on;
subplot(2,1,2); plot(t,u,'LineWidth',1.4);
xlabel('Time (s)'); ylabel('Applied command'); grid on;
end
