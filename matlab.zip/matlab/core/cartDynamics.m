% Control Systems Without the Tears -- educational companion.
function dx = cartDynamics(~,x,u,m)
%CARTDYNAMICS Point-mass upright pendulum; theta positive toward +cart axis.
th=x(3); w=x(4); M=m.M; mp=m.m; ell=m.l;
xdd=(u-m.b*x(2)+mp*ell*sin(th)*w^2 ...
     -mp*9.81*sin(th)*cos(th))/(M+mp*sin(th)^2);
thdd=(9.81*sin(th)-cos(th)*xdd)/ell;
dx=[x(2);xdd;w;thdd];
end
