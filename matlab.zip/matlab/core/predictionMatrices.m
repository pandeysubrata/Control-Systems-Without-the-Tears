% Control Systems Without the Tears -- educational companion.
function [F,G] = predictionMatrices(A,B,C,N)
%PREDICTIONMATRICES Stack predicted y(k+1)...y(k+N), D=0, SISO input.
n=size(A,1); ny=size(C,1); nu=size(B,2);
F=zeros(N*ny,n); G=zeros(N*ny,N*nu);
for i=1:N
    rows=(i-1)*ny+(1:ny); F(rows,:)=C*A^i;
    for j=1:i
        cols=(j-1)*nu+(1:nu); G(rows,cols)=C*A^(i-j)*B;
    end
end
end
