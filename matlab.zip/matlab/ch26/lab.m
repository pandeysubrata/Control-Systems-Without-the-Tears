%% Extended investigation: Check the implemented law against its own log
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
Ts=0.01; N=500;
p=struct('Kp',2,'Ki',1,'Kd',0,'Tf',0.05,'Ts',Ts, ...
    'beta',1,'lo',0,'hi',1,'Kaw',3);
s=pidInit(0,0,0,p); y=0; residual=zeros(1,N); reset=false(1,N);
for k=1:N
    r=0.8; oldI=s.I; error=r-y;
    [u,s,v]=pidStep(r,y,s,p);
    if k==250
        s.I=0; reset(k)=true;
    end
    predictedChange=Ts*(p.Ki*error+p.Kaw*(u-v));
    residual(k)=(s.I-oldI)-predictedChange;
    y=exp(-Ts)*y+(1-exp(-Ts))*u;
end
plot((0:N-1)*Ts,residual); xlabel('Time (s)');
ylabel('Integrator update residual');
fprintf('Largest residual outside reset: %g\n',max(abs(residual(~reset))));
assert(max(abs(residual(~reset)))<1e-12);
% Log pre-update and post-update state explicitly on real hardware.
