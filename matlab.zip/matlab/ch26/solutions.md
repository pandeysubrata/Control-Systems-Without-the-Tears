# Chapter 26: exercise guidance

The typeset version is in Appendix D of the book. Mathematical notation is retained below.

## Exercise 1

Log reference, measured output, requested and applied command, integral contribution and timestamps. A persistent maximum applied command together with a target above the attainable equilibrium indicates unreachability. A large stored integral that delays recovery after the target becomes reachable indicates windup. The two conditions can occur in the same experiment.

## Exercise 2

Define $r_{I,k}=I_{k+1}-I_k-T_s[K_ie_k+K_{aw}(u_k-v_k)]$. It should be near numerical roundoff in a deterministic correctly aligned simulation. A nonzero value can identify reset logic, parameter changes, logging misalignment or implementation disagreement. Include mode flags before interpreting every spike as a bug.

## Exercise 3

Derivative amplification of sensor noise and quantization-induced switching are two possibilities. Repeat with derivative disabled while preserving the measurement record; separately increase numerical resolution in simulation. Also inspect raw sensor data and command spectra if appropriate. Changing both derivative filtering and resolution at once would make the diagnosis ambiguous.

## Exercise 4

Store the computed command and apply the previous one during the next plant update. Keep the initial stored command explicit. Compare output, command and stability indicators with unchanged gains. If behavior worsens, the result supports a timing explanation; redesigning the controller belongs in a separate follow-up test.

## Exercise 5

If the sensor reports $y_m=y+b_s$ and the loop drives $y_m$ to $r$, the physical output is $y=r-b_s$. The controller cannot distinguish this offset from the true output using that sensor alone. A calibration check or independent measurement is needed to establish physical accuracy.

## Exercise 6

A defensible sequence first checks sign and units with bounded actuation, then logs saturation and integral state, then tests timing or resonance hypotheses on a known model. For each test, write the expected observation if the hypothesis is true and what result would weaken it. Finish by repeating the original failing scenario after the smallest justified correction.