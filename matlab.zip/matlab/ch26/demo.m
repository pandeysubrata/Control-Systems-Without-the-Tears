%% Chapter 26: short experiment
% Intended as a short run; actual timing depends on MATLAB and hardware.
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
% Diagnose before retuning: log reference, measurement, raw and applied command.
Ts=0.01; count=800; a=exp(-Ts/0.4); b=1-a;
p=struct('Kp',2,'Ki',3,'Kd',0.04,'Tf',0.03,'Ts',Ts, ...
         'beta',1,'lo',0,'hi',1,'Kaw',3);
s=pidInit(0,0,0,p); x=0; log=zeros(count,5); rng(26,'twister');
for k=1:count
    r=0.8; y=x+0.01*randn; [u,s,raw]=pidStep(r,y,s,p);
    log(k,:)=[r y raw u s.I]; x=a*x+b*u;
end
figure; subplot(2,1,1); plot((0:count-1)*Ts,log(:,1:2));
legend('Reference','Measured'); ylabel('Output');
subplot(2,1,2); plot((0:count-1)*Ts,log(:,3:5));
legend('Raw','Applied','Integral'); xlabel('Time (s)');
fprintf('Saturated fraction %.3f\n',mean(abs(log(:,3)-log(:,4))>1e-10));
