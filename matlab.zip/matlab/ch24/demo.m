%% Chapter 24: short experiment
% Intended as a short run; actual timing depends on MATLAB and hardware.
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
% Quantization and one sample of computation delay in a PI loop.
Ts=0.01; a=exp(-Ts/0.3); b=1-a; count=800;
p=struct('Kp',2,'Ki',4,'Kd',0,'Tf',0.02,'Ts',Ts, ...
         'beta',1,'lo',0,'hi',1,'Kaw',4);
x=0; s=pidInit(0,0,0,p); applied=0; y=zeros(1,count); u=y;
for k=1:count
    measured=round(x*1023)/1023;
    [requested,s]=pidStep(0.6,measured,s,p);
    next=round(requested*255)/255;
    y(k)=x; u(k)=applied; x=a*x+b*applied; applied=next;
end
plotPair((0:count-1)*Ts,y,u,0.6,'Quantized delayed implementation');
% Use hardware timestamps to verify the actual sample schedule.
