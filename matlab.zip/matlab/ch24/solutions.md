# Chapter 24: exercise guidance

The typeset version is in Appendix D of the book. Mathematical notation is retained below.

## Exercise 1

Augment the state with a held input: $\frac{d}{dt}[x;u]=[A,B;0,0][x;u]$. Over one interval its exponential is $[A_d,B_d;0,I]$. The upper-left block is $e^{AT_s}$ and the upper-right is the input integral. This construction remains valid when $A$ is singular, unlike formulas that explicitly use $A^{-1}$.

## Exercise 2

With 256 representable levels including both endpoints, the step is $1/255\approx0.00392157$ and the maximum in-range rounding error is $1/510\approx0.00196078$. A quantizer defined with a different endpoint or full-scale convention may use $1/256$ instead. State the implemented convention rather than relying on the phrase ``8-bit'' alone.

## Exercise 3

Keep the controller and plant parameters fixed and activate one imperfection at a time. Compare target error, oscillation, command transitions and settling. The delayed-only case changes loop phase; the quantized-only case changes the signal resolution and may create a small limit cycle. A combined run then reveals interactions that neither isolated run captures.

## Exercise 4

List sensing, estimation, control, output and logging costs plus interrupt interference. Measure distributions and observed maxima on the target under realistic load. Also measure measurement age and actuator timing. A nominal sum below the sample period is necessary but does not establish a worst-case deadline guarantee.

## Exercise 5

Software-in-the-loop tests the implementation against a simulated plant in software. Processor-in-the-loop runs the controller on the target processor while the surrounding plant or inputs remain simulated. Hardware-in-the-loop exercises selected real interfaces with an emulator or controlled setup. Each validates different boundaries; identify exactly which hardware and plant effects remain absent.

## Exercise 6

Define initial integral and derivative states, actuator state on disable, handling of missing data, and the condition for re-enable. A bumpless transfer may initialize the integral to match the current applied command. Fault behavior must remain bounded and coordinated with the physical plant. Test repeated transitions, not only the first startup.