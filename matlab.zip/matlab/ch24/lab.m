%% Extended investigation: Deadline statistics are part of the controller record
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
rng(24); N=10000; period=5; % All timing quantities are milliseconds.
sense=1.2+0.08*abs(randn(N,1));
estimate=0.5+0.04*abs(randn(N,1));
control=1.8+0.12*abs(randn(N,1));
output=0.6+0.06*abs(randn(N,1));
interrupt=zeros(N,1); interrupt(1:137:end)=1.1;
total=sense+estimate+control+output+interrupt;
missed=total>period; sorted=sort(total);
p99=sorted(ceil(0.99*N));
fprintf('Synthetic mean %.3f ms, 99th percentile %.3f ms\n',mean(total),p99);
fprintf('Observed maximum %.3f ms, missed cycles %d of %d\n', ...
    max(total),sum(missed),N);
subplot(2,1,1); plot(total); hold on; plot([1 N],[period period],'--');
ylabel('Cycle duration (ms)');
subplot(2,1,2); histogram(total,50); xlabel('Duration (ms)'); ylabel('Count');
% Replace these synthetic arrays with measured target timestamps.
% Preserve the test conditions and timer resolution in the report.
