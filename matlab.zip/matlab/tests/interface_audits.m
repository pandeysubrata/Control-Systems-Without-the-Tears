%% Core interface audits
clear; close all; clc;
here=fileparts(mfilename('fullpath')); addpath(fullfile(here,'..','core'));

%% bookModels
m=bookModels();
assert(abs(-m.motor.C*(m.motor.A\m.motor.B)-1/1.08)<1e-12);
assert(m.cart.B(2)>0 && m.cart.B(4)<0);
assert(size(m.cart.C,2)==size(m.cart.A,1));
disp(m.motor);

%% zohExact
Ts=0.1; A=[0 1;0 0]; B=[0;1];
[Ad,Bd]=zohExact(A,B,Ts);
assert(norm(Ad-[1 Ts;0 1],Inf)<1e-12);
assert(norm(Bd-[Ts^2/2;Ts],Inf)<1e-12);

%% simDiscrete
A=0.5; B=1; C=1; D=0;
U=[1 0 0]; x0=0;
[Y,X]=simDiscrete(A,B,C,D,U,x0);
disp(Y); disp(X);
% Check the function signature and expected pre-update sequence.
assert(norm(Y-[0 1 0.5],Inf)<1e-12);

%% freqResponse
w=logspace(-2,2,50); A=-2; B=3; C=1; D=0;
h=freqResponse(A,B,C,D,w,0);
expected=3./(1i*w+2);
assert(max(abs(h(:)-expected(:)))<1e-12);

%% stepMetrics
t=(0:0.001:8)'; y=1-exp(-t);
s=stepMetrics(t,y,1,0);
assert(abs(s.settling+log(0.02))<0.002);
sbad=stepMetrics(t,0.9*y,1,0);
assert(isnan(sbad.settling));

%% pidInit
p=struct('Kp',2,'Ki',1,'Kd',0.1,'Tf',0.05, ...
 'Ts',0.01,'beta',1,'lo',0,'hi',1,'Kaw',3);
s=pidInit(0.3,0.4,0.8,p);
[u,s,v]=pidStep(0.8,0.3,s,p); %#ok<ASGLU>
assert(abs(v-0.4)<1e-12 && abs(u-0.4)<1e-12);

%% pidStep
p=struct('Kp',2,'Ki',1,'Kd',0,'Tf',0.05, ...
 'Ts',0.01,'beta',1,'lo',0,'hi',1,'Kaw',3);
s=pidInit(0,0,0,p); old=s.I;
[u,s,v]=pidStep(2,0,s,p);
assert(u>=0 && u<=1);
assert(abs((s.I-old)-p.Ts*(p.Ki*2+p.Kaw*(u-v)))<1e-12);

%% riccatiDiscrete
[K,P,info]=riccatiDiscrete(1,1,1,1);
expectedP=(1+sqrt(5))/2;
assert(abs(P-expectedP)<1e-8);
assert(abs(K-P/(1+P))<1e-10);
assert(info.radius<1);

%% kalmanStep
xh=0; P=1;
[xh,P,nu,S]=kalmanStep(xh,P,0,1,1,0,1,0,0.25);
assert(abs(xh-0.8)<1e-12);
assert(abs(P-0.2)<1e-12);
assert(abs(nu-1)<1e-12 && abs(S-1.25)<1e-12);

%% predictionMatrices
a=0.8; b=0.2; c=1;
[F,G]=predictionMatrices(a,b,c,3);
assert(norm(F-[a;a^2;a^3],Inf)<1e-12);
expected=[b 0 0;a*b b 0;a^2*b a*b b];
assert(norm(G-expected,Inf)<1e-12);

%% boxQP
H=[4 1;1 2]; f=[-3;-2];
[x,info]=boxQP(H,f,[0;0],[0.4;1],[0;0],5000,1e-10);
assert(info.converged);
assert(norm(x-[0.4;0.8],Inf)<1e-8);

%% simpleMPC
[F,G]=predictionMatrices(0.9,0.1,1,10);
model=struct('F',F,'G',G,'Q',eye(10),'R',0.1*eye(10), ...
 'N',10,'lo',0,'hi',1,'uref',1);
[u,mem,info]=simpleMPC(0,1,model,[]); %#ok<ASGLU>
assert(u>=0 && u<=1 && numel(mem)==10);

%% delayPlant
[A,B,C]=delayPlant(0.8,0.2,3);
x=zeros(4,1); y=zeros(1,6);
for k=1:6
 y(k)=C*x;
 x=A*x+B*(k==1);
end
disp(y); % First nonzero recorded output occurs after the queue delay.
assert(all(abs(y(1:4))<1e-12) && abs(y(5)-0.2)<1e-12);

%% cartDynamics
m=bookModels(); dx=cartDynamics(0,zeros(4,1),1,m.cart);
assert(abs(dx(2)-2)<1e-12);
assert(abs(dx(4)+1/(0.5*0.3))<1e-12);
assert(dx(1)==0 && dx(3)==0);

%% fitARX1
u=[1 -1 1 1 -1 0 1 0]; y=zeros(size(u));
for k=1:numel(u)-1, y(k+1)=0.8*y(k)+0.2*u(k); end
[a,b,res]=fitARX1(u,y);
assert(abs(a-0.8)<1e-12 && abs(b-0.2)<1e-12);
assert(norm(res)<1e-12);

%% plotPair
t=0:0.01:5; y=1-exp(-t); u=ones(size(t));
plotPair(t,y,u,1,'A labeled baseline');
% Add physical units to the generated axes for a report.
% Preserve t, y and u with the model and controller parameters.
