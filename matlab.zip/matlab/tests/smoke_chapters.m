function report=smoke_chapters()
% Run each short demo in an isolated function workspace and report errors.
% Optional branches require installed AND licensed toolboxes.
folder=fileparts(fileparts(mfilename('fullpath')));
report=struct('chapter',{},'passed',{},'seconds',{},'message',{});
for chapter=1:27
    filename=fullfile(folder,sprintf('ch%02d',chapter),'demo.m');
    started=tic; passed=true; message='';
    try
        runOne(filename);
    catch exception
        passed=false; message=exception.message;
    end
    report(chapter)=struct('chapter',chapter,'passed',passed, ...
        'seconds',toc(started),'message',message);
    close all;
end
disp(struct2table(report));
end
function runOne(filename)
run(filename);
end
