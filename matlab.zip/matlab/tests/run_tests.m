%% Run base-MATLAB interface and numerical assertions.
% These tests must be executed by the reader in MATLAB; not pre-certified.
here=fileparts(mfilename('fullpath'));
run(fullfile(here,'interface_audits.m'));
disp('All interface assertions completed.');
