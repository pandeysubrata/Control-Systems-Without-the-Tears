# Chapter 18: exercise guidance

The typeset version is in Appendix D of the book. Mathematical notation is retained below.

## Exercise 1

Ideal-state LQR receives all states exactly, while measured-output PID may receive only one noisy signal. The comparison therefore mixes controller structure with sensing information. Add an observer under the same sensor assumptions, or label ideal-state LQR as a theoretical baseline. Include the observer's initialization, delay and computation in a practical comparison.

## Exercise 2

At equilibrium, $r=ar+bu_s$, so $u_s=(1-a)r/b=0.05/0.1=0.5$. This is within the unit input box. A constant state-update disturbance changes the required input; nominal feedforward alone does not automatically adapt to it.

## Exercise 3

Generate one noise record and reuse it in every architecture. Specify whether the scalar output equals the state, whether filtering is used and how an observer is initialized. Avoid independent random records when trying to attribute a small difference to controller design. Repeat across seeds when estimating a distribution of performance.

## Exercise 4

One acceptable set is tracking IAE, peak or integrated applied effort, maximum constraint violation and a high-percentile computation time with missed-deadline count. Define each formula and observation window. Report hard failures separately; a weighted average score can conceal an unacceptable constraint violation.

## Exercise 5

Selecting the best run removes information about sensitivity to initial conditions, noise and solver reliability. Report all declared scenarios or summarize their distribution and failure count. A controller whose best run is excellent but whose typical run misses a deadline may be a poor engineering choice.

## Exercise 6

For a slow single-input heater with mild constraints, a well-implemented PI controller may offer sufficient performance with low computational cost. MPC becomes more attractive when preview, interacting constraints or anticipation of delay provides a demonstrated benefit. Base the recommendation on measured requirements, model quality and available processor resources rather than a controller-family hierarchy.