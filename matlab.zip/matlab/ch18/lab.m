%% Extended investigation: A comparison table must include the failures
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
Ts=0.1; N=160; t=(0:N-1)*Ts; rows=[];
for b=[0.08 0.1 0.12]
    p=struct('Kp',1,'Ki',0.4,'Kd',0,'Tf',0.1, ...
        'Ts',Ts,'beta',1,'lo',0,'hi',1,'Kaw',2);
    s=pidInit(0,0,0,p); x=0; Y=zeros(1,N); U=Y; V=Y;
    for k=1:N
        Y(k)=x;
        [U(k),s,V(k)]=pidStep(1,x,s,p);
        d=-0.02*(k>=80);
        x=0.95*x+b*U(k)+d;
    end
    post=t>=8; iae=trapz(t,abs(1-Y));
    clipped=Ts*sum(abs(U-V)>1e-9);
    endError=1-mean(Y(end-9:end));
    rows(end+1,:)=[b iae max(abs(U)) clipped endError ...
        trapz(t(post),abs(1-Y(post)))]; %#ok<AGROW>
end
disp('b, total IAE, peak applied u, clipped seconds, end error, late IAE');
disp(rows);
% Append all runs, including failures, before ranking methods.
% Runtime measurements require repeated warmed-up runs on your machine.
