%% Chapter 18: short experiment
% Intended as a short run; actual timing depends on MATLAB and hardware.
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
% Same scalar plant, sample time, disturbance and actuator bounds.
a=0.95; b=0.1; Ts=0.1; count=120; r=1;
[K,~,~]=riccatiDiscrete(a,b,1,0.2); xs=r; us=(1-a)*xs/b;
N=12; [F,G]=predictionMatrices(a,b,1,N);
model=struct('F',F,'G',G,'Q',eye(N),'R',0.2*eye(N), ...
             'N',N,'lo',0,'hi',1,'uref',us);
p=struct('Kp',1,'Ki',0.4,'Kd',0,'Tf',0.02,'Ts',Ts, ...
         'beta',1,'lo',0,'hi',1,'Kaw',2);
Y=zeros(3,count); U=Y;
for method=1:3
    x=0; s=pidInit(0,0,0,p); mem=[];
    for k=1:count
        Y(method,k)=x;
        if method==1, [u,s]=pidStep(r,x,s,p);
        elseif method==2, u=min(1,max(0,us-K*(x-xs)));
        else, [u,mem]=simpleMPC(x,r,model,mem); end
        U(method,k)=u; d=-0.02*(k>=70); x=a*x+b*u+d;
    end
end
figure; subplot(2,1,1); plot((0:count-1)*Ts,Y); ylabel('Output');
legend('PI','LQR + target','Input-box MPC');
subplot(2,1,2); plot((0:count-1)*Ts,U); ylabel('Command'); xlabel('Time (s)');
% This compares these declared architectures, not all possible PID/LQR/MPC designs.
