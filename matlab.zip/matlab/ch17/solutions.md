# Chapter 17: exercise guidance

The typeset version is in Appendix D of the book. Mathematical notation is retained below.

## Exercise 1

Solve $r=2u_s+\hat d$ to obtain $u_s=(r-\hat d)/2$. Check $0\leq u_s\leq1$. If this fails, the target is unreachable under the assumed steady model and limits. Choose and document a supervisory response rather than assuming an optimizer or integrator can make the target feasible.

## Exercise 2

An output bias adds directly to the measured output. An input disturbance passes through plant dynamics and delay, so its transient effect is generally different. A constant output-bias model can remove some steady discrepancies, but it does not reproduce every disturbance path. Offset-free design also depends on estimator structure and steady-target calculations.

## Exercise 3

Write $Y\leq y_{\max}\mathbf1+\epsilon\mathbf1$ with $\epsilon\geq0$ and add a stated penalty such as $\rho\epsilon^2$ to the objective. The slack makes this selected output constraint soft. Keep physical actuator bounds hard if they truly cannot be exceeded. A soft bound permits violations and must never be described as guaranteed enforcement.

## Exercise 4

Hold sample time, weights, limits and scenarios fixed, then vary the number of prediction steps. Report prediction duration as well as step count. Measure solve-time distributions on the same warmed-up environment and retain missed tolerances or deadlines. A longer horizon can improve anticipation while increasing computation and conditioning difficulty.

## Exercise 5

Explicit MPC precomputes a control law, commonly piecewise affine for suitable parametric linear-quadratic problems, and evaluates it online. Nonlinear MPC uses nonlinear prediction or constraints and typically solves a nonlinear optimization online. They address different computational and modeling choices; neither phrase means a universally more advanced or better controller.

## Exercise 6

Specify a bounded fallback command or backup controller, define the trigger and retain state continuity on entry and exit. Test one missed solve, repeated misses and recovery. Holding the previous command can be acceptable in one plant and dangerous in another. The policy must be justified by the plant's dynamics and operating envelope, not by convenience.