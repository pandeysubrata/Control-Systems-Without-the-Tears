%% Extended investigation: A target can be mathematically clear and physically unreachable
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
targets=[0.5 1 1.5 2.2]; biases=[-0.5 0 0.3]; rows=[];
for d=biases
    for r=targets
        us=(r-d)/2; feasible=(us>=0 && us<=1);
        reachable=min(2+d,max(d,r));
        rows(end+1,:)=[r d us feasible reachable]; %#ok<AGROW>
    end
end
disp('Target, output bias, required duty, feasible, nearest reachable target');
disp(rows);
[A,B,C]=delayPlant(exp(-2/80),2*(1-exp(-2/80)),3);
for N=[3 5 10 20 40]
    [F,G]=predictionMatrices(A,B,C,N); %#ok<ASGLU>
    first=find(abs(G(:,1))>1e-12,1);
    if isempty(first), first=NaN; end
    fprintf('Horizon %d: first affected output %g, norm(G) %.4g\n', ...
        N,first,norm(G,'fro'));
end
% A feasible steady target does not imply every transient bound is feasible.
% A queued heater command can affect temperature after duty is reduced.
