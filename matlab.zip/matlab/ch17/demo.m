%% Chapter 17: short experiment
% Intended as a short run; actual timing depends on MATLAB and hardware.
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
% Constant output-bias estimation plus a recomputed steady-state target.
Ts=2; a=exp(-Ts/80); b=2*(1-a); [A,B,C]=delayPlant(a,b,3);
N=20; [F,G]=predictionMatrices(A,B,C,N);
model=struct('F',F,'G',G,'Q',eye(N),'R',0.02*eye(N), ...
             'N',N,'lo',0,'hi',1,'uref',0.5);
x=zeros(4,1); xn=x; dhat=0; mem=[]; count=160; y=zeros(1,count); u=y;
for k=1:count
    actualBias=-0.15*(k>=70); y(k)=C*x+actualBias;
    dhat=dhat+0.15*(y(k)-C*xn-dhat);
    target=1-dhat; model.uref=target/2;
    [u(k),mem]=simpleMPC(xn,target,model,mem);
    x=A*x+B*u(k); xn=A*xn+B*u(k);
end
plotPair((0:count-1)*Ts,40*y,100*u,40,'Bias-compensated thermal MPC');
% This example estimates an output bias. It is not a general disturbance observer.
