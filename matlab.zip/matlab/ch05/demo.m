%% Chapter 05: short experiment
% Intended as a short run; actual timing depends on MATLAB and hardware.
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
% Start with PI: derivative is optional, not a compulsory ingredient.
m=bookModels(); Ts=0.002; t=0:Ts:6;
[Ad,Bd]=zohExact(m.motor.A,m.motor.B,Ts);
p=struct('Kp',0.8,'Ki',2,'Kd',0,'Tf',0.02,'Ts',Ts, ...
         'beta',1,'lo',-12,'hi',12,'Kaw',4);
x=[0;0]; r=10; s=pidInit(0,0,0,p);
y=zeros(size(t)); u=y; disturbance=0.3*(t>=3);
for k=1:numel(t)
    y(k)=m.motor.C*x;
    [u(k),s]=pidStep(r,y(k),s,p);
    x=Ad*x+Bd*(u(k)-disturbance(k));
end
plotPair(t,y,u,r,'Motor PI'); disp(stepMetrics(t,y,r,0));
if exist('pidtune','file')==2
    P=ss(m.motor.A,m.motor.B,m.motor.C,0);
    Ct=pidtune(P,'PI'); disp(Ct);
end
% Compare disturbances using the same injection point and units.
