# Chapter 5: exercise guidance

The typeset version is in Appendix D of the book. Mathematical notation is retained below.

## Exercise 1

For the ideal form $K_p[1+1/(T_is)+T_ds]$, parallel gains are $K_p=3$, $K_i=K_p/T_i=1.5$ and $K_d=K_pT_d=0.3$. Derivative filtering is an additional parameter, not included in this conversion. Check the software's controller form before copying values between interfaces.

## Exercise 2

With $C=K_p+K_i/s$ and $P=K/(\tau s+1)$, the characteristic equation is $s(\tau s+1)+K(K_ps+K_i)=0$. Therefore it is $\tau s^2+(1+KK_p)s+KK_i=0$. Divide by $\tau$ before matching a monic second-order target polynomial.

## Exercise 3

Match $(1+2K_p)/0.5=2(0.7)(3)=4.2$, giving $K_p=0.55$. Match $2K_i/0.5=9$, giving $K_i=2.25$. The resulting closed-loop numerator contains a zero from the PI controller, so a standard zero-free second-order overshoot formula is not automatically exact for the reference response.

## Exercise 4

Differentiating the error includes the derivative of a reference step, producing an ideal impulse in continuous time or a large discrete kick. Differentiating the measurement removes that direct reference derivative. A real change in the measured output can still produce a derivative response, and measurement noise still needs appropriate filtering.

## Exercise 5

Keep the initial condition, voltage limit, disturbance input location and sample interval fixed. Compare post-disturbance IAE, overshoot, recovery time and applied voltage. A larger integral gain can improve low-frequency recovery while reducing damping or increasing time in saturation. The correct conclusion is tied to the specified requirements, not to the smallest error score alone.

## Exercise 6

Do not deliberately drive sustained oscillation on a plant where the excursion can damage equipment, exceed a travel or temperature limit, or create an uncontrolled motion hazard. An unstable plant is also a poor candidate for casually applying an ultimate-gain recipe. Use a model-based or bounded identification approach appropriate to the actual system and its commissioning constraints.