%% Extended investigation: Tune for disturbance recovery as well as the first step
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
m=bookModels(); Ts=0.002; t=0:Ts:8;
[A,B]=zohExact(m.motor.A,m.motor.B,Ts);
results=[]; figure;
for ki=[0.5 2 6]
    p=struct('Kp',0.8,'Ki',ki,'Kd',0,'Tf',0.02, ...
        'Ts',Ts,'beta',1,'lo',-12,'hi',12,'Kaw',4);
    state=pidInit(0,0,0,p); x=zeros(2,1);
    Y=zeros(size(t)); U=Y;
    for k=1:numel(t)
        Y(k)=m.motor.C*x;
        [U(k),state]=pidStep(10,Y(k),state,p);
        disturbance=0.4*(t(k)>=4);
        x=A*x+B*(U(k)-disturbance);
    end
    ix=t>=4;
    results(end+1,:)=[ki trapz(t(ix),abs(10-Y(ix))) ...
        max(Y)-10 max(abs(U))]; %#ok<AGROW>
    plot(t,Y,'DisplayName',sprintf('Ki=%g',ki)); hold on;
end
xlabel('Time (s)'); ylabel('Speed (rad/s)'); legend('Location','best');
disp('Ki, post-disturbance IAE, peak excess speed, peak voltage');
disp(results);
% Retain the reference step and disturbance in every comparison.
