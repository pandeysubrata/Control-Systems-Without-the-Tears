# Chapter 1: exercise guidance

The typeset version is in Appendix D of the book. Mathematical notation is retained below.

## Exercise 1

The plant is the vehicle's longitudinal dynamics; the actuator is the engine or motor through its drive train; the sensor measures vehicle speed; the controller compares that measurement with the requested speed. Road slope and wind are disturbances. Throttle or torque request is not the measured output. This distinction matters because a constant throttle does not imply constant speed on a changing slope.

## Exercise 2

Substitute $u=2(1-y)$ into $y=3u$: $y=6(1-y)$, hence $7y=6$. The closed-loop gain is $6/7$ and the unit-reference error is $1/7$. Increasing gain can reduce this static error in the ideal model, but this algebra contains no dynamics, delay, noise or actuator bound. It therefore cannot justify an arbitrarily high physical gain.

## Exercise 3

If $y_m=T+b_s$ and integral action drives $r-y_m$ to zero, the true temperature tends to $T=r-b_s$. The controller has achieved its measured objective while missing the physical objective. No choice of integral gain identifies an unknown sensor bias from this measurement alone. Calibration or independent information is required.

## Exercise 4

Use the actual disturbance convention in the script. For a plant $\tau\dot y=-y+Ku-d$ and $K=1.5$, open-loop $u=0.5$ gives $y_\infty=0.75-d$. With $K_p=2$, $y_\infty=(3r-d)/4$. Compare values after sufficient settling time and retain the transient. If the script places the disturbance at another location, derive the equilibrium for that location instead of reusing these numbers.

## Exercise 5

The information path includes angle and angular-rate information, controller calculation, wheel or motor torque, body motion and sensing. Upright angle cannot be ignored; angular rate must be measured or estimated well enough for damping. Wheel position or velocity may also be necessary to prevent the robot from balancing while running away. A diagram should identify every measured and estimated signal separately.

## Exercise 6

One acceptable specification is a declared tracking-error band reached within a stated time, a maximum overshoot under a stated reference step, and a bound on applied actuator command. Include initial conditions, disturbance scenario and observation duration. Numerical limits depend on the selected plant; they should not be borrowed from an unrelated example merely to produce a pass.