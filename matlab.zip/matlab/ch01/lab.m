%% Extended investigation: A feedback contract before a gain
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
Ts=0.005; t=0:Ts:10; gains=[1.5 2 2.5];
reference=1; tau=0.5; kp=2;
rows=zeros(2*numel(gains),5); row=0;
figure; hold on;
for gain=gains
    for mode=1:2
        y=0; output=zeros(size(t)); command=output;
        for k=1:numel(t)
            loadValue=0.25*(t(k)>=5);
            if mode==1
                u=0.5; % Nominal inverse for gain 2.
            else
                u=kp*(reference-y);
            end
            output(k)=y; command(k)=u;
            a=exp(-Ts/tau);
            y=a*y+(1-a)*(gain*u-loadValue);
        end
        row=row+1;
        early=mean(output(t>4 & t<5));
        late=mean(output(t>9));
        rows(row,:)=[gain mode early late max(abs(command))];
        plot(t,output,'DisplayName',sprintf('K=%g, mode=%d',gain,mode));
    end
end
xlabel('Time (s)'); ylabel('Output'); legend('Location','best');
disp('Columns: plant gain, mode (1=open,2=P), early, late, peak u');
disp(rows);
% Compare the late values with the equilibrium formulas.
% Change only the disturbance magnitude for the next experiment.
