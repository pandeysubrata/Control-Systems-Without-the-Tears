%% Chapter 01: short experiment
% Intended as a short run; actual timing depends on MATLAB and hardware.
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
% A load disturbance exposes the weakness of open-loop calibration.
Ts=0.01; t=0:Ts:12; a=exp(-Ts/0.5); b=2*(1-a);
r=1; load=0.25*(t>=5); yo=0; yc=0;
Y=zeros(2,numel(t)); U=Y;
for k=1:numel(t)
    uo=r/2; uc=2*(r-yc);
    Y(:,k)=[yo;yc]; U(:,k)=[uo;uc];
    yo=a*yo+b*uo-(1-a)*load(k);
    yc=a*yc+b*uc-(1-a)*load(k);
end
figure; plot(t,Y,'LineWidth',1.4); hold on;
plot(t,0*t+r,'k--'); xlabel('Time (s)'); ylabel('Output');
legend('Calibrated open loop','P feedback','Reference'); grid on;
fprintf('Final open/P errors: %.4f %.4f\n',r-Y(1,end),r-Y(2,end));
% Try changing the plant gain from 2 to 1.5 without changing the controllers.
