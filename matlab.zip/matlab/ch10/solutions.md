# Chapter 10: exercise guidance

The typeset version is in Appendix D of the book. Mathematical notation is retained below.

## Exercise 1

The desired polynomial is $(s+1)(s+4)=s^2+5s+4$. The controlled mass-spring matrix gives polynomial $s^2+(1.2+k_2)s+(4+k_1)$. Hence $K=[0,3.8]$. The zero position gain is a consequence of the existing spring coefficient already matching the desired constant term, not a general feature of pole placement.

## Exercise 2

The controllability matrix is $[B,AB]=[0,1;1,-1.2]$, which has nonzero determinant and rank two. With $C=[1,0]$, the observability matrix is $[C;CA]=[1,0;0,1]$, also rank two. These calculations establish the properties for this exact model; numerical rank tests on poorly scaled high-order models need more care.

## Exercise 3

For $K=[2,3.8]$, the closed-loop dynamics have static equation $0=-6y+Nr$. Unit reference gain therefore requires $N=6$. Equivalently use $N=-1/[C(A-BK)^{-1}B]$. The formula assumes no direct feedthrough and an invertible relevant steady-state mapping.

## Exercise 4

The multiplier supplies the nominal equilibrium input. An unknown constant load changes the force balance, so the nominal multiplier no longer produces the exact target. Feedback reduces the error but does not generally remove it without an internal model of the constant disturbance, such as suitable integral action.

## Exercise 5

Use $T=[0,1;1,0]$. Then $A_z=TAT^{-1}$, $B_z=TB$, $C_z=CT^{-1}$ and $K_z=KT^{-1}$. Transform the initial state and any state covariance as well. Verify both command and output trajectories; identical eigenvalues alone do not detect an incorrectly transformed output row.

## Exercise 6

Choose two stable pole sets and compute their gains and reference multipliers. Use identical initial conditions, reference and input limits. Faster poles often demand more peak input and greater sensitivity to unmodeled dynamics, but quantify the actual trajectories. If one design clips, distinguish its nonlinear limited response from the nominal pole-placement prediction.