%% Extended investigation: State coordinates change the numbers, not the physics
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
A=[0 1;-4 -1.2]; B=[0;1]; C=[1 0]; K=[2 3.8];
T=[0 1;1 0]; Az=T*A/T; Bz=T*B; Cz=C/T; Kz=K/T;
Ts=0.01; [Ad,Bd]=zohExact(A,B,Ts);
[Adz,Bdz]=zohExact(Az,Bz,Ts);
x=[0.3;-0.2]; z=T*x; N=400; err=zeros(1,N);
ux=zeros(1,N); uz=ux; yx=ux; yz=ux;
for k=1:N
    ux(k)=-K*x; uz(k)=-Kz*z;
    yx(k)=C*x; yz(k)=Cz*z;
    err(k)=norm(z-T*x,Inf);
    x=Ad*x+Bd*ux(k); z=Adz*z+Bdz*uz(k);
end
fprintf('Maximum coordinate consistency error: %g\n',max(err));
fprintf('Maximum output discrepancy: %g\n',max(abs(yx-yz)));
assert(max(err)<1e-10);
subplot(2,1,1); plot((0:N-1)*Ts,yx,(0:N-1)*Ts,yz,'--');
ylabel('Position'); legend('Original','Reordered');
subplot(2,1,2); plot((0:N-1)*Ts,ux,(0:N-1)*Ts,uz,'--');
xlabel('Time (s)'); ylabel('Command');
% Intentionally omit the gain transformation to see a silent error.
