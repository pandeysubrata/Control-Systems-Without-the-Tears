%% Chapter 10: short experiment
% Intended as a short run; actual timing depends on MATLAB and hardware.
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
% State feedback on a mass-spring-damper: direct coefficient matching.
A=[0 1;-4 -1.2]; B=[0;1]; C=[1 0];
desired=[-2 -3]; q=poly(desired);
K=[q(3)-4 q(2)-1.2]; Acl=A-B*K;
Nbar=-1/(C*(Acl\B));
Ts=0.01; t=0:Ts:6; [Ad,Bd]=zohExact(Acl,B*Nbar,Ts);
y=simDiscrete(Ad,Bd,C,0,ones(1,numel(t)),[0;0]);
figure; plot(t,y); xlabel('Time (s)'); ylabel('Position'); grid on;
disp(eig(Acl)); fprintf('Reference multiplier %.4f\n',Nbar);
Co=[B A*B]; Ob=[C;C*A]; fprintf('Ranks: %d %d\n',rank(Co),rank(Ob));
if exist('place','file')==2, disp(place(A,B,desired)); end
