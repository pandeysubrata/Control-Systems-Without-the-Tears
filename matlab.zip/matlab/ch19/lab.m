%% Extended investigation: A finite uncertainty grid is evidence with a boundary
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
kp=1; ki=1; gains=linspace(0.5,1.5,21);
taus=linspace(0.3,2,21); slow=zeros(numel(taus),numel(gains));
damping=slow;
for i=1:numel(taus)
    for j=1:numel(gains)
        K=gains(j); tau=taus(i);
        rootsHere=roots([tau 1+K*kp K*ki]);
        slow(i,j)=max(real(rootsHere));
        damping(i,j)=(1+K*kp)/(2*sqrt(tau*K*ki));
    end
end
imagesc(gains,taus,slow); axis xy; colorbar;
xlabel('Plant gain'); ylabel('Time constant (s)');
title('Largest pole real part: linear PI family');
[value,index]=max(slow(:)); [i,j]=ind2sub(size(slow),index);
fprintf('Slowest tested pole real part: %g at K=%g, tau=%g\n', ...
    value,gains(j),taus(i));
assert(all(slow(:)<0));
% This assertion concerns the sampled linear parameter grid only.
% The coefficient argument covers positive continuous parameters.
% Neither statement includes saturation, delay or neglected modes.
