%% Chapter 19: short experiment
% Intended as a short run; actual timing depends on MATLAB and hardware.
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
% Robustness begins with a family, not a more impressive controller name.
Ts=0.005; t=0:Ts:8; kp=1; ki=1; figure; hold on;
for gain=[0.7 1 1.3]
    for tau=[0.5 1 1.5]
        a=exp(-Ts/tau); b=gain*(1-a); x=0; I=0; y=zeros(size(t));
        for k=1:numel(t)
            y(k)=x; e=1-x; u=kp*e+I; I=I+Ts*ki*e;
            x=a*x+b*u;
        end
        plot(t,y);
    end
end
xlabel('Time (s)'); ylabel('Output across nine plants'); grid on;
% A finite grid is a stress test, not a proof over every parameter value.
