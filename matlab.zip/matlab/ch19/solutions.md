# Chapter 19: exercise guidance

The typeset version is in Appendix D of the book. Mathematical notation is retained below.

## Exercise 1

Parameter uncertainty changes a model coefficient, such as load inertia or resistance. A process disturbance enters the plant, such as load torque. Sensor bias changes the reported measurement, such as a speed offset. Their effects appear at different locations in the loop, so one disturbance model cannot automatically represent all three.

## Exercise 2

Nine points leave infinitely many intermediate values untested and may omit combinations or dynamic uncertainty. A response can be worst between sampled points. A proof over a continuous set requires an appropriate analytical or certified numerical argument. The sweep is still useful evidence when its domain and limitations are stated clearly.

## Exercise 3

A motor held at one constant speed and nearly constant voltage may not reveal the transient dynamics or distinguish several parameters. Excitation must vary enough to expose the relevant modes while remaining within the intended operating region. More data at the same uninformative condition does not necessarily resolve identifiability.

## Exercise 4

A reward based only on tracking error may encourage excessive actuator effort, overheating or rapid switching. If travel limits are absent from the objective and constraints, a learned policy may exploit motion that would be unacceptable physically. State hard requirements separately and test the policy under distribution shifts and model error.

## Exercise 5

Apply identical actuator limits across the grid and record tracking, saturation duration and any failure criterion. Define the worst case using the declared requirement rather than whichever trace looks most dramatic. A worst tested case is not a certified worst case over the entire uncertainty region.

## Exercise 6

One justified direction is robust control for a flexible motor load whose resonance varies over a measured interval. The burden includes a defensible uncertainty model, robust stability and performance analysis, and validation on held-out configurations. Adaptive or learning methods need similarly explicit assumptions about excitation, convergence, constraints and deployment evidence.