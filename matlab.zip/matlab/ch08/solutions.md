# Chapter 8: exercise guidance

The typeset version is in Appendix D of the book. Mathematical notation is retained below.

## Exercise 1

Use $20\log_{10}$ for amplitude ratios: two is approximately $6.0206$ dB, one half is $-6.0206$ dB and ten is 20 dB. The factor ten applies to a power ratio. Confusing the two factors can create a substantial error in a crossover or attenuation calculation.

## Exercise 2

The phase is $-\omega T_d=-5(0.05)=-0.25$ radians, or approximately $-14.3239$ degrees. This is the contribution of the additional pure delay at that frequency. If the rest of the loop changes its crossover, recompute the total margin at the actual crossover.

## Exercise 3

For real frequency, $e^{-j\omega T_d}$ lies on the unit circle, so its magnitude is one. Its phase decreases linearly with frequency. A delay can therefore severely reduce stability margin without changing the loop's magnitude curve, which is why a gain-only comparison can be misleading.

## Exercise 4

Locate a sign change in the zero-dB magnitude and interpolate in log frequency. Compare a coarse and fine grid while preserving the frequency range. If several crossings exist, report all relevant ones rather than choosing whichever looks favorable. For the simple example a refined grid should converge toward a stable estimate, subject to numerical precision.

## Exercise 5

A scalar phase margin at one crossing does not describe every loop topology, every crossing or every uncertainty. Unstable open-loop poles require the correct Nyquist argument. Multivariable interactions, large model changes, saturation and delay variation can lie outside the meaning of the reported margin. State the model and robustness question the margin is being used to address.

## Exercise 6

A low-pass filter attenuates high-frequency measurement noise but contributes phase lag and may move crossover. Insert it into the loop model and recompute the full loop response. Compare actuator noise as well as output noise; a quiet-looking filtered measurement is not sufficient evidence of a robust closed loop.