%% Extended investigation: Spend a phase budget on a sensor filter
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
w=logspace(-3,3,6000); s=1i*w;
base=2./(s.*(1+0.5*s)); report=[];
figure;
for Tf=[0 0.05 0.2]
    loop=base./(1+Tf*s);
    mag=20*log10(abs(loop)); ph=unwrap(angle(loop))*180/pi;
    j=find(mag(1:end-1)>=0 & mag(2:end)<0,1);
    wc=NaN; pm=NaN;
    if ~isempty(j)
        fraction=-mag(j)/(mag(j+1)-mag(j));
        lw=log(w(j))+fraction*(log(w(j+1))-log(w(j)));
        wc=exp(lw); phase=ph(j)+fraction*(ph(j+1)-ph(j));
        pm=180+phase;
    end
    report(end+1,:)=[Tf wc pm]; %#ok<AGROW>
    subplot(2,1,1); hold on; semilogx(w,mag);
    subplot(2,1,2); hold on; semilogx(w,ph);
end
subplot(2,1,1); ylabel('Magnitude (dB)'); legend('Tf=0','0.05','0.2');
subplot(2,1,2); ylabel('Phase (degrees)'); xlabel('Frequency (rad/s)');
disp('Filter time constant, estimated crossover, estimated phase margin');
disp(report);
