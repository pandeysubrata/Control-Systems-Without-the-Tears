%% Chapter 08: short experiment
% Intended as a short run; actual timing depends on MATLAB and hardware.
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
% A first-order plant with an integrator: inspect gain and phase directly.
w=logspace(-2,2,500); K=2;
L=K./(1i*w.*(1+0.5i*w));
figure; subplot(2,1,1); semilogx(w,20*log10(abs(L))); grid on;
ylabel('Magnitude (dB)');
subplot(2,1,2); semilogx(w,unwrap(angle(L))*180/pi); grid on;
ylabel('Phase (deg)'); xlabel('Angular frequency (rad/s)');
[~,j]=min(abs(abs(L)-1));
fprintf('Grid crossover %.4g rad/s, approximate PM %.3g deg\n', ...
        w(j),180+angle(L(j))*180/pi);
if exist('tf','file')==2
    P=tf(2,[0.5 1 0]); figure; margin(P); figure; nyquist(P);
end
% A grid estimate can miss extra crossings; inspect the whole frequency range.
