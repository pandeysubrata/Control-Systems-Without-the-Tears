# Chapter 9: exercise guidance

The typeset version is in Appendix D of the book. Mathematical notation is retained below.

## Exercise 1

The maximum lead is $\sin^{-1}[(1-\alpha)/(1+\alpha)]$. For $\alpha=0.1$, this is approximately $54.9032$ degrees. This is the isolated compensator's maximum phase addition; it is not the final loop phase margin because crossover and plant phase must also be included.

## Exercise 2

With $\alpha=z/p=0.25$ and $\omega_m=\sqrt{zp}=10$, use $z=\omega_m\sqrt\alpha=5$ and $p=\omega_m/\sqrt\alpha=20$ rad/s. Reversing these values produces lag rather than lead. The compensator gain must still be selected for the intended loop crossover.

## Exercise 3

At $s=j\omega_n$, the quadratic terms cancel and the magnitude is $\zeta_z/\zeta_p=0.1$, corresponding to minus twenty decibels. Away from the center frequency the attenuation is smaller and the phase changes. A moving resonance can therefore escape a narrow notch.

## Exercise 4

Inject the same measurement-noise sequence with and without the lead compensator. Record command RMS or a clearly defined band-limited measure, applied limits and tracking error. Lead commonly raises high-frequency command sensitivity, but the exact result depends on normalization and any added roll-off. Keep the noise sample rate and scaling identical.

## Exercise 5

Payload changes can shift the structural resonance away from the notch center. A narrow notch may then provide little attenuation at the new frequency while retaining its own phase effects. Validate across a stated frequency interval, and consider whether a broader filter or a different robust design better addresses the uncertainty.

## Exercise 6

Declare the discretization method and sample interval, then compare magnitude and phase below the useful bandwidth and well below Nyquist. Bilinear transformation warps frequencies; a prewarped design matches a selected frequency. A zero-order-hold equivalent has a different interpretation. Also simulate the implemented difference equation with limits and noise rather than comparing frequency curves alone.