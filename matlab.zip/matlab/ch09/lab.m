%% Extended investigation: A notch is a model-dependent promise
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
wn=20; zz=0.02; zp=0.2;
w=logspace(0,2.3,2000); s=1i*w;
notch=(s.^2+2*zz*wn*s+wn^2)./(s.^2+2*zp*wn*s+wn^2);
subplot(2,1,1); semilogx(w,20*log10(abs(notch)));
ylabel('Magnitude (dB)'); grid on;
subplot(2,1,2); semilogx(w,unwrap(angle(notch))*180/pi);
ylabel('Phase (degrees)'); xlabel('Frequency (rad/s)'); grid on;
actualResonances=wn*[0.8 0.9 1 1.1 1.2];
report=zeros(numel(actualResonances),3);
for k=1:numel(actualResonances)
    wr=actualResonances(k); sr=1i*wr;
    value=(sr^2+2*zz*wn*sr+wn^2)/(sr^2+2*zp*wn*sr+wn^2);
    report(k,:)=[wr 20*log10(abs(value)) angle(value)*180/pi];
end
disp('Actual resonance, attenuation (dB), phase (degrees)');
disp(report);
assert(abs(abs((-(wn^2)+2i*zz*wn^2+wn^2)/ ...
    (-(wn^2)+2i*zp*wn^2+wn^2))-zz/zp)<1e-12);
% Repeat with a wider notch, then compare the phase cost.
