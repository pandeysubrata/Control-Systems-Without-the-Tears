%% Chapter 09: short experiment
% Intended as a short run; actual timing depends on MATLAB and hardware.
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
% Lead raises phase over a finite band; its high-frequency gain also rises.
w=logspace(-2,3,600); wm=4; alpha=0.2;
z=wm*sqrt(alpha); p=wm/sqrt(alpha);
C=(1+1i*w/z)./(1+1i*w/p);
G=1./(1i*w.*(1+0.5i*w));
K=1/abs((1+1i*wm/z)/(1+1i*wm/p)/(1i*wm*(1+0.5i*wm)));
L=K*C.*G;
figure; subplot(2,1,1); semilogx(w,20*log10(abs(L))); grid on;
ylabel('Loop magnitude (dB)');
subplot(2,1,2); semilogx(w,unwrap(angle(L))*180/pi); grid on;
ylabel('Loop phase (deg)'); xlabel('Angular frequency (rad/s)');
fprintf('Lead zero=%g pole=%g gain=%g\n',z,p,K);
if exist('tf','file')==2
    P=tf(1,[0.5 1 0]); Ctf=K*tf([1/z 1],[1/p 1]);
    figure; step(feedback(Ctf*P,1));
    % controlSystemDesigner(P) opens the optional interactive design app.
end
