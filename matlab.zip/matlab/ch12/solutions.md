# Chapter 12: exercise guidance

The typeset version is in Appendix D of the book. Mathematical notation is retained below.

## Exercise 1

With observer $\dot{\hat x}=A\hat x+Bu+L(y-C\hat x)$ and exact noiseless model, $e=x-\hat x$ obeys $\dot e=(A-LC)e$. The known input cancels because both plant and observer use the same applied input. If the observer instead uses an unclipped request, an additional mismatch term appears.

## Exercise 2

For scalar observation matrix one, $L=P^-/(P^-+R)$. With $P^-=2$, the gains are $2/2.5=0.8$ and $2/10=0.2$. The noisier measurement receives less weight in this update. This does not mean the state estimate ignores the measurement forever; the prediction covariance evolves between updates.

## Exercise 3

Covariance is the expected squared deviation, so its units are the square of the measured quantity's units. A standard deviation of 0.2 m corresponds to variance $0.04$ m$^2$. Using 0.2 as the variance changes the statistical model and the relative confidence assigned to the sensor.

## Exercise 4

Insert a declared constant bias and plot innovation and estimation error. A transient innovation shift should appear, but a filter without a bias state can later absorb the offset into its state estimate. Therefore inspect truth error in simulation and do not conclude that a zero late innovation mean proves physical calibration.

## Exercise 5

Use the same position measurements for both estimates. A one-sample difference amplifies high-frequency measurement noise by division by the sample interval. The Kalman estimate uses a motion model and covariance assumptions to trade responsiveness against noise. Compare latency and behavior during acceleration as well as RMS error; smoothness alone is not accuracy.

## Exercise 6

Off-diagonal covariance entries describe correlated measurement errors. Treating correlated sensors as independent can count the same information twice and underestimate uncertainty. Form the covariance from the joint error model or appropriate calibration data. Also consider correlation between process and measurement noise if the physical setup creates it.