%% Chapter 12: short experiment
% Intended as a short run; actual timing depends on MATLAB and hardware.
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
% Position measurements reveal velocity indirectly through a dynamic model.
rng(12,'twister'); Ts=0.05; A=[1 Ts;0 1]; B=[Ts^2/2;Ts]; C=[1 0];
Q=diag([1e-5 1e-4]); R=0.04; x=[0;1]; xh=[0;0]; P=eye(2);
N=250; truth=zeros(2,N); estimate=truth; measured=zeros(1,N);
for k=1:N
    u=0.2*sin(0.06*k);
    x=A*x+B*u+chol(Q,'lower')*randn(2,1);
    y=C*x+sqrt(R)*randn;
    [xh,P]=kalmanStep(xh,P,u,y,A,B,C,Q,R);
    truth(:,k)=x; estimate(:,k)=xh; measured(k)=y;
end
t=(1:N)*Ts; figure;
subplot(2,1,1); plot(t,measured,'.',t,truth(1,:),t,estimate(1,:));
ylabel('Position'); legend('Measured','True','Estimated');
subplot(2,1,2); plot(t,truth(2,:),t,estimate(2,:));
ylabel('Velocity'); xlabel('Time (s)'); legend('True','Estimated');
