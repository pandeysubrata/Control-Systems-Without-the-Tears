%% Extended investigation: The innovation is a diagnostic signal
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
rng(12); N=500; Q=0.001; R=0.04;
x=0; xh=0; P=1; truth=zeros(1,N); estimate=truth;
measurement=truth; innovation=truth; normalized=truth;
for k=1:N
    x=x+sqrt(Q)*randn;
    bias=0.5*(k>250);
    y=x+sqrt(R)*randn+bias;
    [xh,P,nu,S]=kalmanStep(xh,P,0,y,1,0,1,Q,R);
    truth(k)=x; estimate(k)=xh; measurement(k)=y;
    innovation(k)=nu; normalized(k)=nu/sqrt(S);
end
subplot(2,1,1); plot(truth); hold on; plot(estimate);
ylabel('State'); legend('Truth','Estimate');
subplot(2,1,2); plot(normalized); ylabel('Normalized innovation');
xlabel('Sample');
fprintf('Pre-bias innovation mean: %g\n',mean(innovation(100:240)));
fprintf('Late estimation bias: %g\n',mean(estimate(400:end)-truth(400:end)));
% Repeat with a process change instead of a sensor bias.
% Explain what additional measurement could distinguish the cases.
