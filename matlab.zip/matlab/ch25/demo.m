%% Chapter 25: short experiment
% Intended as a short run; actual timing depends on MATLAB and hardware.
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
% Identify a discrete model using separate estimation and validation inputs.
rng(25,'twister'); N=800; u=repelem(2*(rand(1,N/10)>0.5)-1,10);
a=0.94; b=0.08; y=zeros(1,N);
for k=1:N-1, y(k+1)=a*y(k)+b*u(k)+0.01*randn; end
[ahat,bhat,res]=fitARX1(u(1:400),y(1:400));
yhat=zeros(1,400); yhat(1)=y(401);
for k=1:399, yhat(k+1)=ahat*yhat(k)+bhat*u(400+k); end
figure; plot(401:800,y(401:800),401:800,yhat); grid on;
legend('Validation data','Free-run prediction'); xlabel('Sample'); ylabel('Output');
fprintf('a=%g b=%g validation RMSE=%g\n',ahat,bhat, ...
        sqrt(mean((y(401:800)-yhat).^2)));
% The noise is an ARX equation innovation; output-only measurement noise changes LS bias.
if exist('iddata','file')==2
    data=iddata(y(1:400)',u(1:400)',0.1);
    model=tfest(data,1,0); disp(model);
end
