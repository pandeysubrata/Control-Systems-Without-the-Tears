# Chapter 25: exercise guidance

The typeset version is in Appendix D of the book. Mathematical notation is retained below.

## Exercise 1

Differentiate $\norm{Y-\Phi\vartheta}^2$ to obtain $\Phi^T\Phi\vartheta=\Phi^TY$. Backslash can use numerically appropriate factorizations without explicitly forming an inverse; forming normal equations can also worsen conditioning. Full column rank is needed for a unique ordinary least-squares coefficient vector in this basic formulation.

## Exercise 2

The time constant is $-0.1/\log(0.94)\approx1.61615$ s and the static gain is $0.08/(1-0.94)=1.33333$. These interpretations assume the stated first-order ZOH model without a separate delay. A good numerical fit does not by itself prove that this physical interpretation is valid.

## Exercise 3

At a steady operating condition, input and output may provide nearly redundant information about the equilibrium relation while revealing little transient behavior. The regressor columns can become poorly conditioned, making coefficient estimates sensitive to noise. Design bounded changes that excite the dynamics relevant to the intended controller.

## Exercise 4

One-step prediction uses measured past outputs to keep correcting the starting point. Free simulation propagates its own predicted state. A model can therefore have a good one-step score but drift in free simulation. Use the same validation record, initial-condition rule and error metric, and state which prediction mode supports the claimed accuracy.

## Exercise 5

Generate the clean process first, then add sensor noise to the stored output. The noisy past output appears in the regressor, creating an errors-in-variables problem. Repeat over seeds and compare the mean estimate with the known parameters. Do not mistake one near-correct trial for evidence of unbiasedness.

## Exercise 6

Choose a safe operating temperature, subtract documented offsets, apply bounded duty changes with durations that reveal the thermal time scale, and sample fast enough to resolve the relevant delay. Reserve a distinct validation sequence. Record ambient changes and sensor dynamics; otherwise the fitted plant may absorb those effects without a clear interpretation.