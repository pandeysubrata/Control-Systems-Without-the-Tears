%% Extended investigation: A fitted coefficient is only as useful as its validation
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
rng(25); N=600; a=0.94; b=0.08;
u=repelem(2*(rand(1,60)>0.5)-1,10); rows=[];
for sigma=[0 0.01 0.05]
    estimates=zeros(30,2);
    for trial=1:30
        y=zeros(1,N+1);
        for k=1:N, y(k+1)=a*y(k)+b*u(k)+sigma*randn; end
        [ahat,bhat]=fitARX1(u,y(1:N));
        estimates(trial,:)=[ahat bhat];
    end
    rows(end+1,:)=[sigma mean(estimates,1) std(estimates,0,1)]; %#ok<AGROW>
end
disp('Innovation SD, mean a, mean b, SD a, SD b'); disp(rows);
assert(abs(rows(1,2)-a)<1e-10 && abs(rows(1,3)-b)<1e-10);
% Sensor noise is a different experiment from process innovation.
% Add noise to stored y after simulating a clean trajectory to study it.
% Keep the regression assumptions visible when interpreting the result.
