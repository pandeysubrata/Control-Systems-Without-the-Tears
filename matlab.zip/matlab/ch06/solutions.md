# Chapter 6: exercise guidance

The typeset version is in Appendix D of the book. Mathematical notation is retained below.

## Exercise 1

Windup is accumulated controller memory caused by integrating error while the requested action cannot be applied. A saturated P controller can track poorly or oscillate, but it has no integral state to wind up. Other dynamic controller states can also become inconsistent with the applied actuator; the phrase should identify the particular state and mechanism rather than every saturation problem.

## Exercise 2

With derivative memory initialized to zero, $I_0=4-2(0.5\cdot3-1)=3$. The proportional contribution is one and the integral contribution is three, so the first requested command is four. Check that four is within the actuator bounds; otherwise matching the requested command does not mean the applied command can equal four.

## Exercise 3

The state $I$ is stored in actuator units, so $\dot I$ has actuator units per second. The discrepancy $u-v$ has actuator units. Thus $K_{aw}$ has units of inverse seconds. Its numerical value must be interpreted together with the discrete sample interval; an excessively aggressive explicit update can create undesirable dynamics.

## Exercise 4

Use the same unreachable-then-reachable reference profile for all three gains. Log the integral state, requested command and applied command. With zero back-calculation the stored integral tends to remain excessive after the reference returns. Larger back-calculation typically reduces that excess, but very aggressive correction can introduce its own transient or sampled oscillation. Report the observed behavior rather than assuming monotonic improvement.

## Exercise 5

At the upper limit, suppress the ordinary positive integral increment when positive error would drive the requested command still farther above the limit. Permit integration when its sign would move the command back toward the feasible range. Apply the corresponding logic at the lower limit. Include a tolerance around the boundary to avoid decisions dominated by roundoff or noisy equality tests.

## Exercise 6

Update the integration multiplier, derivative finite-difference denominator and derivative-filter coefficient using the new $T_s$. Recompute the plant discretization and any delay queue representing a fixed physical delay. Continuous gains remain the same for this particular experiment, but the implemented discrete controller changes; compare its response and timing budget rather than assuming exact equivalence.