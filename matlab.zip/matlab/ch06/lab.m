%% Extended investigation: Bumpless means matching the command at transfer
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
Ts=0.01; p=struct('Kp',2,'Ki',1,'Kd',0.1,'Tf',0.05, ...
    'Ts',Ts,'beta',1,'lo',0,'hi',1,'Kaw',3);
y0=0.3; r=0.8; uManual=0.4; N=300;
figure; firstCommands=zeros(1,2);
for mode=1:2
    s=pidInit(y0,uManual,r,p);
    if mode==1, s.I=0; end
    y=y0; Y=zeros(1,N); U=Y; integral=Y;
    for k=1:N
        Y(k)=y;
        [U(k),s]=pidStep(r,y,s,p);
        integral(k)=s.I;
        y=exp(-Ts)*y+(1-exp(-Ts))*U(k);
    end
    firstCommands(mode)=U(1);
    subplot(2,1,1); hold on; plot((0:N-1)*Ts,U);
    subplot(2,1,2); hold on; plot((0:N-1)*Ts,integral);
end
subplot(2,1,1); ylabel('Applied command'); legend('Zero I','Matched I');
subplot(2,1,2); ylabel('Integral contribution'); xlabel('Time (s)');
disp('First commands: zero initialization, matched initialization');
disp(firstCommands);
assert(abs(firstCommands(2)-uManual)<1e-12);
