%% Chapter 06: short experiment
% Intended as a short run; actual timing depends on MATLAB and hardware.
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
% An unreachable request stores integral action unless tracking prevents it.
Ts=0.01; t=0:Ts:14; a=exp(-Ts); b=1-a;
r=2*(t<5)+0.5*(t>=5); figure; hold on;
for kaw=[0 3]
    p=struct('Kp',2,'Ki',1,'Kd',0.05,'Tf',0.05,'Ts',Ts, ...
             'beta',1,'lo',0,'hi',1,'Kaw',kaw);
    s=pidInit(0,0,0,p); x=0; y=zeros(size(t)); I=y; u=y;
    for k=1:numel(t)
        y(k)=x; [u(k),s]=pidStep(r(k),y(k),s,p);
        I(k)=s.I; x=a*x+b*u(k);
    end
    subplot(3,1,1); hold on; plot(t,y);
    subplot(3,1,2); hold on; plot(t,u);
    subplot(3,1,3); hold on; plot(t,I);
end
subplot(3,1,1); plot(t,r,'k--'); ylabel('Output');
legend('No tracking','Anti-windup','Reference');
subplot(3,1,2); ylabel('Applied command');
subplot(3,1,3); ylabel('Integral state'); xlabel('Time (s)');
