%% Chapter 11: short experiment
% Intended as a short run; actual timing depends on MATLAB and hardware.
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
% A small initial lean, with full-state feedback first.
m=bookModels(); Ts=0.01; [A,B]=zohExact(m.cart.A,m.cart.B,Ts);
Q=diag([10 1 150 2]); R=0.1; [K,P,info]=riccatiDiscrete(A,B,Q,R);
x=[0;0;5*pi/180;0]; t=0:Ts:5; X=zeros(4,numel(t)); U=zeros(size(t));
for k=1:numel(t)
    X(:,k)=x; U(k)=-K*x; x=A*x+B*U(k);
end
figure; subplot(2,1,1); plot(t,X(3,:)*180/pi); ylabel('Lean (deg)');
subplot(2,1,2); plot(t,U); ylabel('Cart force (N)'); xlabel('Time (s)');
disp(K); disp(info);
% This run is deliberately unsaturated and uses every true state.
if exist('dlqr','file')==2
    Kref=dlqr(A,B,Q,R); fprintf('Gain difference %.3g\n',norm(K-Kref));
end
