%% Extended investigation: Changing units should not change an optimal decision
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
m=bookModels(); Ts=0.01;
[A,B]=zohExact(m.cart.A,m.cart.B,Ts);
Q=diag([10 1 150 2]); R=0.1;
[K,P,info]=riccatiDiscrete(A,B,Q,R);
T=diag([1000 1000 1 1]);
Az=T*A/T; Bz=T*B; Qz=(T')\Q/T;
[Kz,Pz,infoz]=riccatiDiscrete(Az,Bz,Qz,R);
disp('Original gain'); disp(K);
disp('Transformed gain expressed in original coordinates'); disp(Kz*T);
fprintf('Relative gain discrepancy: %g\n',norm(K-Kz*T)/norm(K));
x=[0.01;0;0.05;0]; z=T*x;
fprintf('Original state cost: %g\n',x'*Q*x);
fprintf('Transformed state cost: %g\n',z'*Qz*z);
fprintf('Closed-loop radii: %g, %g\n',info.radius,infoz.radius);
assert(abs(x'*Q*x-z'*Qz*z)<1e-10);
% Poor coordinate scaling may also slow the educational iteration.
% Compare with dlqr when Control System Toolbox is available.
% Do not equate a small raw residual with a well-scaled problem.
