# Chapter 13: exercise guidance

The typeset version is in Appendix D of the book. Mathematical notation is retained below.

## Exercise 1

For $\eta_{k+1}=\eta_k+T_s(r_k-Cx_k)$, the augmented state matrix is $[A,0;-T_sC,1]$, input matrix $[B;0]$ and reference injection $[0;T_s]$. Dimensions follow the number of plant states and integrated outputs. If the integral convention is reversed, the corresponding signs and gain interpretation must also change.

## Exercise 2

The law is $u=-K_xx-K_\eta\eta$. With $\eta$ accumulating positive reference-minus-output error, an increased positive integral state should often increase the input. That requires a negative $K_\eta$ in this convention. Judging a gain by its sign without reading the state and feedback definitions can lead to an incorrect correction.

## Exercise 3

Nominal feedforward remains fixed after an unknown constant load change, leaving an equilibrium error in general. Integral action changes its stored state until it supplies the additional input, provided the target is reachable and the augmented closed loop is stable. Use the same disturbance location and sensor information when comparing the two designs.

## Exercise 4

Clip voltage before the motor update and plot the integral state. An unreachable reference causes accumulation that the unconstrained LQI design did not account for. Returning to a reachable reference can reveal slow recovery. A practical comparison should then introduce a specified anti-windup design rather than simply retuning the unconstrained weights.

## Exercise 5

For the ideal linear setup with suitable assumptions, controller and observer poles can be designed separately and the combined dynamics have the corresponding eigenvalues. This is a structural result, not a robustness guarantee under saturation, delay, model error or arbitrary noise statistics. LQG optimality also depends on the specified quadratic cost and stochastic assumptions.

## Exercise 6

Give both architectures the same measured output, sample rate, noise sequence and delays. If state feedback needs unmeasured states, supply an observer built from declared information. Include estimator computation and initialization in the comparison. Alternatively compare ideal-state designs explicitly as theoretical baselines, without presenting that result as a sensor-equivalent hardware contest.