%% Chapter 13: short experiment
% Intended as a short run; actual timing depends on MATLAB and hardware.
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
% Augment a sampled motor with integrated speed error.
m=bookModels(); Ts=0.01; [A,B]=zohExact(m.motor.A,m.motor.B,Ts); C=m.motor.C;
Aa=[A zeros(2,1);-Ts*C 1]; Ba=[B;0];
[K,~,info]=riccatiDiscrete(Aa,Ba,diag([0.01 1 10]),0.2);
x=[0;0]; eta=0; r=10; t=0:Ts:8; y=zeros(size(t)); u=y;
for k=1:numel(t)
    y(k)=C*x; u(k)=-K*[x;eta];
    eta=eta+Ts*(r-y(k));
    disturbance=0.4*(t(k)>=4);
    x=A*x+B*(u(k)-disturbance);
end
plotPair(t,y,u,r,'Integral state feedback'); disp(K); disp(info);
% No saturation in this first experiment. Add anti-windup before deployment.
