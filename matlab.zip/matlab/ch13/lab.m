%% Extended investigation: An integrator adds authority and a failure mode
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
m=bookModels(); Ts=0.01;
[A,B]=zohExact(m.motor.A,m.motor.B,Ts); C=m.motor.C;
Aa=[A zeros(2,1);-Ts*C 1]; Ba=[B;0];
[K,~,~]=riccatiDiscrete(Aa,Ba,diag([0.01 1 10]),0.2);
x=zeros(2,1); eta=0; t=0:Ts:12;
Y=zeros(size(t)); U=Y; V=Y; I=Y; ref=10+10*(t<5);
for k=1:numel(t)
    y=C*x; v=-K*[x;eta]; u=min(12,max(-12,v));
    Y(k)=y; U(k)=u; V(k)=v; I(k)=eta;
    x=A*x+B*u;
    eta=eta+Ts*(ref(k)-y);
end
subplot(3,1,1); plot(t,Y,t,ref,'--'); ylabel('Speed');
subplot(3,1,2); plot(t,U,t,V,'--'); ylabel('Voltage');
legend('Applied','Requested');
subplot(3,1,3); plot(t,I); ylabel('Integral state'); xlabel('Time (s)');
fprintf('Maximum available nominal speed: %g rad/s\n',12/1.08);
% This baseline intentionally has no LQI anti-windup correction.
% Describe a correction before comparing it with this trace.
