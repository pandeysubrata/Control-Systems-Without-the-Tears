function startup_book()
root=fileparts(mfilename('fullpath')); addpath(fullfile(root,'core'));
fprintf('Open a chapter folder and run demo.m.\n');
end
