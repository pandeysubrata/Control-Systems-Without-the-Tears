%% Chapter 02: short experiment
% Intended as a short run; actual timing depends on MATLAB and hardware.
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
% One physical motor, two state coordinates, one measured speed.
m=bookModels(); A=m.motor.A; B=m.motor.B; C=m.motor.C;
Ts=0.002; t=0:Ts:3; [Ad,Bd]=zohExact(A,B,Ts);
U=3*ones(1,numel(t)); [Y,X]=simDiscrete(Ad,Bd,C,0,U,[0;0]);
figure; subplot(2,1,1); plot(t,Y); ylabel('Speed (rad/s)');
subplot(2,1,2); plot(t,X(1,1:end-1)); ylabel('Current (A)');
xlabel('Time (s)');
xsteady=-A\(B*3); fprintf('Steady speed %.4f rad/s\n',C*xsteady);
% Optional Control System Toolbox route:
if exist('ss','file')==2
    P=ss(A,B,C,0); figure; step(3*P); grid on;
    G=tf(P); disp(G);
end
% State x=[current; angular speed]. Position requires another integrator.
