%% Extended investigation: Does the reduced motor earn its simplicity?
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
m=bookModels(); Ts=0.001; t=0:Ts:1;
[A,B]=zohExact(m.motor.A,m.motor.B,Ts);
ar=exp(-2.16*Ts); br=(2/2.16)*(1-ar);
x=zeros(2,1); wr=0;
fullSpeed=zeros(size(t)); reducedSpeed=fullSpeed;
fullCurrent=fullSpeed; algebraicCurrent=fullSpeed;
u=3*(t>=0.02 & t<0.22);
for k=1:numel(t)
    fullSpeed(k)=x(2); fullCurrent(k)=x(1);
    reducedSpeed(k)=wr;
    algebraicCurrent(k)=(u(k)-m.motor.K*wr)/m.motor.R;
    x=A*x+B*u(k);
    wr=ar*wr+br*u(k);
end
subplot(2,1,1);
plot(t,fullSpeed,t,reducedSpeed,'--');
ylabel('Speed (rad/s)'); legend('Full','Reduced');
subplot(2,1,2);
plot(t,fullCurrent,t,algebraicCurrent,'--');
xlabel('Time (s)'); ylabel('Current (A)');
legend('Dynamic current','Algebraic estimate');
fprintf('Peak speed difference: %.6g rad/s\n', ...
    max(abs(fullSpeed-reducedSpeed)));
fprintf('Exact DC gain: %.9g rad/s/V\n', ...
    -m.motor.C*(m.motor.A\m.motor.B));
% Repeat with a shorter pulse before accepting the reduction.
