# Chapter 2: exercise guidance

The typeset version is in Appendix D of the book. Mathematical notation is retained below.

## Exercise 1

Kirchhoff's law gives $L\dot i=u-Ri-K_e\omega$ and torque balance gives $J\dot\omega=K_ti-b\omega$. Substituting the stated constants yields $\dot i=-100i-4\omega+50u$ and $\dot\omega=4i-2\omega$. Current is amperes, speed is radians per second and input is volts. The off-diagonal terms have different units even though both happen to have numerical magnitude four.

## Exercise 2

At equilibrium, $4i-2\omega=0$, so $i=\omega/2$. The electrical equation becomes $0=-50\omega-4\omega+50u$, giving $\omega/u=50/54=1/1.08$. Equivalently calculate $-CA^{-1}B$. The gain is approximately $0.925926$ rad/s/V; twelve volts supports approximately $11.1111$ rad/s in this nominal unloaded model.

## Exercise 3

With state $[i,\omega,\theta]^T$, append $\dot\theta=\omega$. Thus $A_3=[-100,-4,0;4,-2,0;0,1,0]$, $B_3=[50,0,0]^T$. For position output, $C_3=[0,0,1]$ and $D=0$. For both speed and position, stack the corresponding output rows. The added zero eigenvalue represents position integration, not an electrical instability.

## Exercise 4

Choose an equilibrium $T_0$ and $u_0=(T_0-T_a)/80$. Define $\widetilde T=T-T_0$ and $\widetilde u=u-u_0$. Then $\dot{\widetilde T}=-\widetilde T/80+\widetilde u$. If the physical input is limited, the deviation-input bounds become the original bounds minus $u_0$. Forgetting that shift can make a controller request an impossible negative heater duty.

## Exercise 5

A realization is any state-space representation with the required input-output behavior. Similarity transformations mix state coordinates while preserving the transfer function. The resulting states can be mathematical combinations of current, speed or other variables. A state-feedback gain must use the same coordinates as its model or an explicitly transformed estimate; matching matrix dimensions alone does not establish physical consistency.

## Exercise 6

Near zero, $\sin\theta\approx\theta$, so $\ddot\theta\approx(g/l)\theta$. The positive coefficient indicates upright instability in this convention. At larger angles, the neglected nonlinear terms are no longer small relative to the desired accuracy. The approximation also says nothing about input saturation or cart travel, which can invalidate a local controller even at a moderate initial angle.