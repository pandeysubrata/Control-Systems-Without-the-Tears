# Chapter 23: exercise guidance

The typeset version is in Appendix D of the book. Mathematical notation is retained below.

## Exercise 1

For normalized deviation $x=(T-T_a)/40$, convert a bound using $x_{\min}=(T_{\min}-T_a)/40$ and similarly for the maximum. With $T_a=20$ degrees Celsius, an upper limit of 70 degrees becomes 1.25. Temperature differences in Celsius and kelvin have the same numerical scale, but absolute offsets must not be mixed.

## Exercise 2

For state $[x,q_1,q_2,q_3]^T$, $A=[a,0,0,b;0,0,0,0;0,1,0,0;0,0,1,0]$, $B=[0,1,0,0]^T$ and $C=[1,0,0,0]$. Here $a=e^{-T_s/80}$ and $b=2(1-a)$. The input queue contains duty values, while the first state is normalized temperature rise.

## Exercise 3

Keep weights, model, limits and initial state identical. The preview run uses the known scheduled future reference; the other repeats the current reference. Compare behavior before and after the scheduled change, applied duty and tracking error. Explain that the result includes the value of forecast information, not merely a different tuning choice.

## Exercise 4

With $Y=Fx+GU$, require $GU\leq y_{\max}\mathbf1-Fx$. Lower bounds give $-GU\leq Fx-y_{\min}\mathbf1$. These are coupled linear inequalities, not independent input boxes. The supplied projected box solver cannot enforce them; use an appropriate general constrained solver or a separately justified formulation.

## Exercise 5

Heat already stored in the process or queued through the input delay can continue to raise temperature after the current command is set to zero. A future bound may therefore be infeasible from the present state. A feasibility policy must distinguish impossible constraints from numerical solver failure and define the response before deployment.

## Exercise 6

Use synchronized input, an independent or faster temperature measurement if available, and an excitation that resolves the initial response. Pure input delay produces a period with no plant response; sensor lag smooths and delays the reported response dynamically. In noisy limited data these effects can be hard to distinguish, so compare candidate models on separate validation records.