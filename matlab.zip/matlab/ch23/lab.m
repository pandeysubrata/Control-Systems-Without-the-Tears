%% Extended investigation: Preview helps only when the future is actually known
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
Ts=2; Np=25; Nsim=160;
[A,B,C]=delayPlant(exp(-Ts/80),2*(1-exp(-Ts/80)),3);
[F,G]=predictionMatrices(A,B,C,Np);
model=struct('F',F,'G',G,'Q',eye(Np),'R',0.03*eye(Np), ...
    'N',Np,'lo',0,'hi',1,'uref',0.5);
schedule=ones(Nsim+Np+1,1); schedule(101:end)=0.5;
figure;
for preview=0:1
    x=zeros(4,1); mem=[]; Y=zeros(Nsim,1); U=Y;
    for k=1:Nsim
        Y(k)=C*x;
        if preview, target=schedule(k+1:k+Np);
        else, target=repmat(schedule(k),Np,1); end
        model.uref=schedule(k)/2;
        [U(k),mem,info]=simpleMPC(x,target,model,mem);
        if ~info.converged, warning('QP tolerance missed at %d',k); end
        x=A*x+B*U(k);
    end
    subplot(2,1,1); hold on; plot((0:Nsim-1)*Ts,20+40*Y);
    subplot(2,1,2); hold on; plot((0:Nsim-1)*Ts,100*U);
end
subplot(2,1,1); ylabel('Temperature (deg C)'); legend('No preview','Preview');
subplot(2,1,2); ylabel('Heater duty (%)'); xlabel('Time (s)');
