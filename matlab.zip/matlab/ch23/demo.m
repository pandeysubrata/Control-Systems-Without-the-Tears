%% Chapter 23: short experiment
% Intended as a short run; actual timing depends on MATLAB and hardware.
clear; close all; clc;
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'..','core'));
% Heater request, transport delay, duty saturation, and a changing target.
Ts=2; a=exp(-Ts/80); b=2*(1-a); [A,B,C]=delayPlant(a,b,3);
N=25; [F,G]=predictionMatrices(A,B,C,N);
model=struct('F',F,'G',G,'Q',eye(N),'R',0.03*eye(N), ...
             'N',N,'lo',0,'hi',1,'uref',0.5);
count=160; ref=ones(1,count); ref(100:end)=0.5;
x=zeros(4,1); mem=[]; Y=zeros(1,count); U=Y; res=Y;
for k=1:count
    Y(k)=C*x; model.uref=ref(k)/2;
    future=ref(min(k+(1:N),count))';
    [U(k),mem,info]=simpleMPC(x,future,model,mem);
    res(k)=info.residual; x=A*x+B*U(k);
end
plotPair((0:count-1)*Ts,20+40*Y,100*U,20+40*ref,'Heater project');
fprintf('Worst QP residual %g\n',max(res));
% The preview uses a scheduled reference, not an unknown future disturbance.
